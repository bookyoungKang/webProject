package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/algorithm/submitquestionok.do")
public class SubmitQuestionOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//SubmitQuestionOk.java
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String languageType = req.getParameter("sels");
		String submitCode = req.getParameter("submitCode");
		String questionNum = req.getParameter("seq"); //문제 번호
		String id = session.getAttribute("certification").toString();
		
		//selected
		String sel = req.getParameter("sels");
		req.setAttribute("sel", sel);

		QuestionDAO dao = new QuestionDAO();
		SubmitDTO dto = new SubmitDTO();
		
		dto.setLanguageType(languageType);
		dto.setQuestionNum(questionNum);
		dto.setSubmitCode(submitCode);
		dto.setId(id);
		
		int result = dao.addSubmit(dto);
		
		req.setAttribute("questionNum", questionNum);
		req.setAttribute("result", result);
		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/submitquestionok.jsp");
		dispatcher.forward(req, resp);

	}

}