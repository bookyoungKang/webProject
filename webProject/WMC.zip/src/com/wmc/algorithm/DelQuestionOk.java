package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 알고리즘 문제 삭제확인하는 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/delquestionok.do")
public class DelQuestionOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//DelQuestionOk.java
		//String seq = req.getParameter("seq");
		
		//req.setAttribute("seq", seq);
		
		
		String seq = req.getParameter("seq");
		
		QuestionDAO dao = new QuestionDAO();
		
		int result = dao.delQuestion(seq);
		
		req.setAttribute("result", result);
		
		System.out.println(result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/delquestionok.jsp");
		dispatcher.forward(req, resp);

	}

}