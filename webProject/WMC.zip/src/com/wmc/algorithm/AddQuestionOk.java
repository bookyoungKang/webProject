package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 알고리즘 문제 추가 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/addquestionok.do")
public class AddQuestionOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddQuestionOk.java
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String questionName = req.getParameter("questionName");
		String questionContent = req.getParameter("questionContent");
		String input = req.getParameter("input");
		String output = req.getParameter("output");
		String ex = req.getParameter("ex");
		String id = session.getAttribute("certification").toString();
		String sourceId = session.getAttribute("certification").toString();
		//String seq = req.getParameter("seq");

		QuestionDAO dao = new QuestionDAO();
		
		QuestionDTO dto = new QuestionDTO();
		
		
		dto.setId(id);
		dto.setSourceId(sourceId);
		dto.setQuestionName(questionName);
		dto.setQuestionContent(questionContent);
		dto.setInput(input);
		dto.setOutput(output);
		dto.setEx(ex);
		dto.setSourceId(sourceId);
		

		int result = dao.addQuestion(dto);
		
		// 문제 추가 게시물 번호
		String maxseq = dao.getSeq();
		req.setAttribute("maxseq", maxseq);
		
		req.setAttribute("result", result);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/addquestionok.jsp");
		dispatcher.forward(req, resp);

	}

}