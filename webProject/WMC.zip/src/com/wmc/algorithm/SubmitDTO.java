package com.wmc.algorithm;

/**
 * 알고리즘 문제 제출 정보 데이터를 담는 클래스
 * @author bey15
 *
 */
public class SubmitDTO {

	private String seq;           // num
	private String questionNum;   // 문제 테이블 참조 문제번호
	private String id;            // 참조 아이디
	private String languageType;  // 사용언어
	private String submitCode;
	private String regdate;
	private String result;   // 정답 유무
	private String status;

	
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(String questionNum) {
		this.questionNum = questionNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLanguageType() {
		return languageType;
	}
	public void setLanguageType(String languageType) {
		this.languageType = languageType;
	}
	public String getSubmitCode() {
		return submitCode;
	}
	public void setSubmitCode(String submitCode) {
		this.submitCode = submitCode;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
