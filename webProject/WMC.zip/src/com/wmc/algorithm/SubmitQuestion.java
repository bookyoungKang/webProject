package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 알고리즘 문제제출 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/submitquestion.do")
public class SubmitQuestion extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//SubmitQuestion.java
		
		req.setCharacterEncoding("UTF-8");
		
		//active
		String active = req.getParameter("active");
		if(active == null || active.equals("")) active = "3";
		
		req.setAttribute("active", active);
		

		
		
		String seq = req.getParameter("seq");
		String questionName = req.getParameter("questionName");
		
		
		req.setAttribute("seq", seq);  //문제 번호 넘기기
		req.setAttribute("questionName", questionName);//문제 이름 넘기기

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/submitquestion.jsp");
		dispatcher.forward(req, resp);

	}
	


}
