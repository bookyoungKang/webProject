package com.wmc.algorithm;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 알고리즘 문제 리스트 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/questionlist.do")
public class QuestionList extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");

		
		//QuestionList.java
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "1";
		
		String rnum = req.getParameter("rnum");
		
		
		
		//---------------------------------------------------------------------------
		
		QuestionDAO dao = new QuestionDAO();
		
		// 목록 불러오기
		// 검색하기
		
		String column = req.getParameter("column");
		String word = req.getParameter("word");
		boolean isSearch = false;
		
		HashMap<String,String> map = new HashMap<String,String>();
		
		if((column != null && word != null) && (column != "" && word != "")) {
	
			isSearch = true;
			map.put("column",column);
			map.put("word",word);
		
		}
		map.put("isSearch",isSearch + "");
		


	
		
		
		//----------------------------------------------------------------------------
		// 페이징
		int nowPage = 0;        // 현재 페이지 번호
		int totalCount = 0;		// 총 게시물
		int pageSize = 10;		// 한 페이지당 보여줄 게시물 수
		int totalPage = 0;		// 총 페이지 수
		int begin = 0;			// where절 사용
		int end = 0;			// where절 사용
		int n = 0;				// 페이지 바 제작
		int loop = 0;			// 페이지 바 제작
		int blockSize = 10;		// 페이지 바 제작
		
		String page = req.getParameter("page");
		
		if(page == null || page == "") nowPage = 1;  //처음 들어오는 사람
		else nowPage = Integer.parseInt(page);
		
		//현재 페이지 번호 + 연산
		begin = ((nowPage - 1) * pageSize) + 1;
		end = begin + pageSize - 1;
		
		map.put("begin", begin + "");
		map.put("end", end + "");
		
		// 총 게시물 수 알아내기
		totalCount = dao.getTotalCount(map);
		
		// 총 페이지 수 알아내기
		totalPage = (int)Math.ceil((double)totalCount/pageSize);

		
		//----------------------------------------------------------------------------
		
		//페이지 바 제작
		String pagebar = "";
		
		loop = 1;
		n = ((nowPage - 1) / blockSize) * blockSize + 1;
		
		pagebar += "<nav><ul class='pagination pagination-lg'>";
		
		
		if(n == 1) {
			pagebar += String.format("<li>" + 
					"      				<a href='#' aria-label='Previous'>" + 
					"        				<span aria-hidden='true'>&laquo;</span>" + 
					"      				</a>" + 
					"    			  </li>");
		}else {
			pagebar += String.format("<li>" + 
					"      				<a href='/wmc/algorithm/questionlist.do?page=%d' aria-label='Previous'>" + 
					"        				<span aria-hidden='true'>&laquo;</span>" + 
					"      				</a>" + 
					"    			</li>", n-1);
		}
		
	
		
		// 페이지 번호 루프 
		while (!(loop > blockSize || n > totalPage)) {
			if(n == nowPage) {
				pagebar += String.format("<li class='active'><a href='#'>%d</a></li>", n);
			}else {
				pagebar += String.format("<li><a href='/wmc/algorithm/questionlist.do?page=%d'>%d</a></li>", n, n);
			}
			loop++;
			n++;
		}
		
		// 다음 페이징
		if (n > totalPage) {
			pagebar += String.format("<li>" + 
					"      				<a href='#' aria-label='Next'>" + 
					"        				<span aria-hidden='true'>&raquo;</span>" + 
					"      				</a>" + 
					"    			</li>");
		}else {
			pagebar += String.format("<li>" + 
					"      				<a href='/wmc/algorithm/questionlist.do?page=%d'aria-label='Next'>" + 
					"        				<span aria-hidden='true'>&raquo;</span>" + 
					"      				</a>" + 
					"    			</li>", n);
		}
		
		
		pagebar += "</ul>\r\n" + "</nav>";
		
	
		//----------------------------------------------------------------------------
		ArrayList<QuestionListDTO> list = dao.list(map);  // 조심 !!
		
		req.setAttribute("pagebar", pagebar);
		req.setAttribute("totalCount", totalCount);
		req.setAttribute("totalPage", totalPage);
		req.setAttribute("nowPage", nowPage);
		
		req.setAttribute("isSearch", isSearch);
		req.setAttribute("column", column);
		req.setAttribute("word", word);
		
		req.setAttribute("list", list);
		req.setAttribute("active", active);
		req.setAttribute("rnum", rnum);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/questionlist.jsp");
		dispatcher.forward(req, resp);

	}

}





