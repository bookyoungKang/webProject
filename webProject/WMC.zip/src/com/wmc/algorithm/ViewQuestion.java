package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 알고리즘 문제보는 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/viewquestion.do")
public class ViewQuestion extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//ViewQuestion.java
		
		String active = req.getParameter("active");
		if(active == null || active.equals("")) active = "1";
		
		req.setAttribute("active", active);
		
		// 돌아다니는 아이디 ------수정하기 버튼 만들기 위해서 -------------
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String id = session.getAttribute("certification").toString();
		//--------------------------------------------------
		//관리자    -- 확인 !!!!!!!
		String rating = session.getAttribute("rating").toString();
		
		//--------------------------------------------------
		
		String seq = req.getParameter("seq");
		
		QuestionDAO dao = new QuestionDAO();
		QuestionDTO dto = dao.get(seq);
		
		req.setAttribute("dto", dto);
		req.setAttribute("seq", seq);
		//--------------------------------------------------
		// joinQuestion에서 제출 정답률 등 가져오기
		QuestionListDTO vdto = dao.viewBar(seq);
		
		req.setAttribute("vdto", vdto);
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/viewquestion.jsp");
		dispatcher.forward(req, resp);

	}

}