package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 알고리즘 문제 수정하는 클래스
 * @author bey15
 *
 */
@WebServlet("/algorithm/editquestion.do")
public class EditQuestion extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//EditQuestion.java
		
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "2";
		
		req.setAttribute("active", active);
		
		//---------------------------------------------------------------------------------------------------
		
		
		
		String seq = req.getParameter("seq");
		
		QuestionDAO dao = new QuestionDAO();
		QuestionDTO dto = dao.get(seq);
		
		req.setAttribute("dto", dto);
		req.setAttribute("seq", seq);
		
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/editquestion.jsp");
		dispatcher.forward(req, resp);

	}

}
















