package com.wmc.study;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 스터디 탈퇴를 위한 클래스
 * @author bey15
 *
 */
@WebServlet("/study/del/studydel.do")
public class StudyWithdrawal extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		StudyDAO dao = new StudyDAO();
		
		int result = dao.getStudyGroupNum(id); // 가입된 스터디 수 가져오기(스터디는 1개밖에 못든다)
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('가입된 스터디가 없습니다.!')");
			writer.println("history.back()");
			
		}else {
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/del/studywithdrawal.jsp");
			dispatcher.forward(req, resp);
		}
		
		writer.println("</script>");
		
		writer.close();
		

	}

}
