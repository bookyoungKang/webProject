package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 스터디 참가하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/attend.do")
public class Attend extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyNum = req.getParameter("studyNum");
		
		// 지워야됨
		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		StudyDAO dao = new StudyDAO();
		
		int result = 0;
		result = dao.isGroup(id);
		if(result == 0) {
			result = dao.addStudyGroup(id, studyNum);
		}
		System.out.println("result:" + result);
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 1) {
			writer.println("alert('참가 성공!')");
			writer.println("location.href='/wmc/study/recruit/studyrecruitlist.do'");
		}else {
			writer.println("alert('실패!')");
			writer.println("history.back()");
		}
		writer.println("</script>");
		
		writer.close();


	}

}

