package com.wmc.study.recruit;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 스터디 만들기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studyrecruitadd.do")
public class StudyRecruitAdd extends HttpServlet { 
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/recruit/studyrecruitadd.jsp");
		dispatcher.forward(req, resp);
		
	}
	
}
