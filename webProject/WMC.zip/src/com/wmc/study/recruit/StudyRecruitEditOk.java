package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

/**
 * 스터디 수정하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studyrecruiteditok.do")
public class StudyRecruitEditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		
		String studyNum = req.getParameter("studyNum");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String studyName = req.getParameter("studyName");
		int limit = Integer.parseInt(req.getParameter("limit"));
		
		StudyDAO dao = new StudyDAO();
		StudyDTO dto = new StudyDTO();
		
		dto.setStudyNum(studyNum);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setStudyName(studyName);
		dto.setLimit(limit);
		
		int result = dao.editRecruit(dto);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('수정 실패!')");
			writer.println("history.back()");
		}else {
			writer.println("location.href='/wmc/study/recruit/studyrecruitview.do?studyNum=" + studyNum + "'");
		}
		writer.println("</script>");

		writer.close();

	}

}

