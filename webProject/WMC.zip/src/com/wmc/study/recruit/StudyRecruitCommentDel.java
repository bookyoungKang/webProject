package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 스터디 모집공고 댓글 삭제하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studyrecruitcommentdel.do")
public class StudyRecruitCommentDel extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyNum = req.getParameter("studyNum");
		String studyCommentNum = req.getParameter("studyCommentNum");
		
		StudyDAO dao = new StudyDAO();
		
		int result = dao.delStudyComment(studyCommentNum); // 댓글 삭제

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/recruit/studyrecruitview.do?studyNum=" + studyNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();

		

	}

}

