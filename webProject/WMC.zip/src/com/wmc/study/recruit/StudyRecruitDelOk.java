package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

/**
 * 스터디 모집 공고글 삭제하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studyrecruitdelok.do")
public class StudyRecruitDelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyNum = req.getParameter("studyNum");
		
		StudyDAO dao = new StudyDAO();
		int result = dao.delrecruit(studyNum);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		writer.println("location.href='/wmc/study/recruit/studyrecruitlist.do'");
			
		writer.println("</script>");
		
		writer.close();

	}

}

