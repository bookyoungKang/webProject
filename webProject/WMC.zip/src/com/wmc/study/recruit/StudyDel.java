package com.wmc.study.recruit;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

/**
 * 스터디 삭제하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studydel.do")
public class StudyDel extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id = req.getParameter("id");
		
		StudyDAO dao = new StudyDAO();
		
		dao.studyDel(id);


	}

}

