package com.wmc.study.recruit;

/**
 * 스터디 모집공고 댓글 데이터를 담을 클래스
 * @author bey15
 *
 */
public class StudyRecruitCommentDTO {

	private String StudyCommentNum;
	private String studyNum;
	private String id;
	private String content;
	private String regdate;
	
	public String getStudyCommentNum() {
		return StudyCommentNum;
	}
	public void setStudyCommentNum(String studyCommentNum) {
		StudyCommentNum = studyCommentNum;
	}
	public String getStudyNum() {
		return studyNum;
	}
	public void setStudyNum(String studyNum) {
		this.studyNum = studyNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	
	
}
