package com.wmc.study.recruit;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

/**
 * 스터디 수정하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/recruit/studyrecruitedit.do")
public class StudyRecruitEdit extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyNum = req.getParameter("studyNum");
		
		StudyDAO dao = new StudyDAO();
		
		StudyDTO dto = dao.vlist(studyNum);
		
		//dto.setContent(dto.getContent().replace("\r\n", "<br>"));
		
		req.setAttribute("dto", dto);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/recruit/studyrecruitedit.jsp");
		dispatcher.forward(req, resp);

	}

}

