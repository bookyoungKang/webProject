package com.wmc.study.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

/**
 * 스터디 전용 게시판 수정하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboardeditok.do")
public class StudyBoardEditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		
		String studyBoardNum = req.getParameter("studyBoardNum");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String kind = req.getParameter("kind");
		
		StudyDAO dao = new StudyDAO();
		StudyBoardDTO dto = new StudyBoardDTO();
		
		dto.setStudyBoardNum(studyBoardNum);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setKind(kind);
		
		int result = dao.editBoard(dto);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('수정 실패!')");
			writer.println("history.back()");
		}else {
			writer.println("location.href='/wmc/study/board/studyboardview.do?studyBoardNum=" + studyBoardNum + "'");
		}
		writer.println("</script>");

		writer.close();

	}

}
