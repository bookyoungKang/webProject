package com.wmc.study.board;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.recruit.StudyRecruitCommentDTO;

/**
 * 스터디 전용 게시판 상세보기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboardview.do")
public class StudyBoardView extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyBoardNum = req.getParameter("studyBoardNum");
		
		StudyDAO dao = new StudyDAO();
		
		StudyBoardDTO dto = dao.bvlist(studyBoardNum);
		dao.addCntBoard(studyBoardNum); // 스터디전용 게시판 조회수 증가
		
		int commentCnt = dao.countBoardComment(studyBoardNum); // 댓글 수
		ArrayList<StudyBoardCommentDTO> rclist = dao.studyBoardCommentlist(studyBoardNum); // 댓글 리스트 뽑아오기
		
		dto.setContent(dto.getContent().replace("\r\n", "<br>"));
		
		req.setAttribute("dto", dto);
		req.setAttribute("commentCnt", commentCnt);
		req.setAttribute("rclist", rclist);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/board/studyboardview.jsp");
		dispatcher.forward(req, resp);

	}

}
