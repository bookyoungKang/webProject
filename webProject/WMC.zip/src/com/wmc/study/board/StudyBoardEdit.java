package com.wmc.study.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

/**
 * 스터디 전용 게시판 수정하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboardedit.do")
public class StudyBoardEdit extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyBoardNum = req.getParameter("studyBoardNum");
		
		StudyDAO dao = new StudyDAO();
		
		StudyBoardDTO dto = dao.bvlist(studyBoardNum);
		
		//dto.setContent(dto.getContent().replace("\r\n", "<br>"));
		
		req.setAttribute("dto", dto);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/board/studyboardedit.jsp");
		dispatcher.forward(req, resp);

	}

}