package com.wmc.study.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

/**
 * 스터디 전용 게시판 댓글 삭제하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboardcommentdel.do")
public class StudyBoardCommentDel extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyBoardCommentNum = req.getParameter("studyBoardCommentNum");
		String studyBoardNum = req.getParameter("studyBoardNum");
		
		StudyDAO dao = new StudyDAO();
		
		int result = dao.delStudyBoardComment(studyBoardCommentNum); // 댓글 삭제

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/board/studyboardview.do?studyBoardNum=" + studyBoardNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();


	}

}


