package com.wmc.study.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 스터디 전용 게시글 댓글 추가하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboardcommentadd.do")
public class StudyBoardCommentAdd extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		String content = req.getParameter("commenttxt");
		String studyBoardNum = req.getParameter("studyBoardNum");
		
		StudyDAO dao = new StudyDAO();

		StudyBoardCommentDTO dto = new StudyBoardCommentDTO();
		
		dto.setId(id);
		dto.setContent(content);
		dto.setStudyBoardNum(studyBoardNum);
		
		int result = dao.addStudyBoardComment(dto); // 댓글 넣기

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/board/studyboardview.do?studyBoardNum=" + studyBoardNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();

	}

}

