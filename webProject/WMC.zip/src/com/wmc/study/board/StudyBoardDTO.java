package com.wmc.study.board;

/**
 * 스터디 전용 게시판 정보를 담을 클래스
 * @author bey15
 *
 */
public class StudyBoardDTO {

	private String studyBoardNum;
	private String studyNum;
	private String id;
	private String title;
	private String kind;
	private String content;
	private String regdate;
	private String gap;
	private String cnt;
	private String rating;
	private String notice;
	
	public String getStudyBoardNum() {
		return studyBoardNum;
	}
	public void setStudyBoardNum(String studyBoardNum) {
		this.studyBoardNum = studyBoardNum;
	}
	public String getStudyNum() {
		return studyNum;
	}
	public void setStudyNum(String studyNum) {
		this.studyNum = studyNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String grade) {
		this.kind = grade;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public String getGap() {
		return gap;
	}
	public void setGap(String gap) {
		this.gap = gap;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getNotice() {
		return notice;
	}
	public void setNotice(String notice) {
		this.notice = notice;
	}
	
	
	
}
