package com.wmc.study.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

/**
 * 스터디 전용 게시판 삭제하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/board/studyboarddelok.do")
public class StudyBoardDelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyBoardNum = req.getParameter("studyBoardNum");
		
		StudyDAO dao = new StudyDAO();
		int result = dao.delBoard(studyBoardNum);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		writer.println("location.href='/wmc/study/board/studyboardlist.do'");
			
		writer.println("</script>");
		
		writer.close();
		
	}

}
