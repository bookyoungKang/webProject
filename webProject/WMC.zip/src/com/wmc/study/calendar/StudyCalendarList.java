package com.wmc.study.calendar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 스터디 일정 리스트 가져오는 클래스
 * @author bey15
 *
 */
@WebServlet("/study/calendar/studycalendarlist.do")
public class StudyCalendarList extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		String rating = session.getAttribute("rating") + "";

		HashMap<String, String> map = new HashMap<String, String>();

		map.put("rating", rating);
		map.put("id", id);
		
		String kind = req.getParameter("kind");
		map.put("kind", kind);
		
		StudyDAO dao = new StudyDAO();
		String studyNum = dao.getStudyNum(id); // 접속한 아이디의 스터디번호를 가져옴
		
		if (studyNum != null && !studyNum.equals("") || rating.equals("2")) {
			
			String grade = dao.getStudyGrade(id);

			map.put("studyNum", studyNum+"");

			// 페이징 + 페이지바 관련 변수
			int nowPage = 0; // 현재 페이지 번호
			int totalCount = 0; // 총 게시물
			int pageSize = 10; // 한 페이지당 출력 게시물 수
			int totalPage = 0; // 총 페이지
			int begin = 0; // where 절
			int end = 0; // where 절
			int n = 0; // 페이지 바 제작
			int loop = 0; // 페이지 바 제작
			int blockSize = 10; // 페이지 바 제작

			String page = req.getParameter("page");

			if (page == null || page == "")
				nowPage = 1;
			else
				nowPage = Integer.parseInt(page);

			begin = ((nowPage - 1) * pageSize) + 1;
			end = begin + pageSize - 1;

			map.put("begin", begin + "");
			map.put("end", end + "");

			// 총 게시물 수 알아내기
			totalCount = dao.getTotalCountCalendar(map);

			// 총 페이지 수 알아내기
			// 256 / 10 = 25.6 -> 26
			totalPage = (int) Math.ceil((double) totalCount / pageSize);
			
			
			ArrayList<StudyCalendarDTO> calendarList = dao.CalendarList(map); // 스터디번호에 맞는 일정 리스트를 뽑아옴

			if (calendarList != null) {
				for (StudyCalendarDTO rlist : calendarList) {

					int gap = Integer.parseInt(rlist.getGap());
					int cnt = Integer.parseInt(rlist.getCnt());
					String title = rlist.getTitle();

					if (gap < 60) {
						rlist.setGap(gap + "분전");
					} else if (gap < (60 * 24)) {
						rlist.setGap(gap / 60 + "시" + gap % 60 + "분 전");
					} else {
						rlist.setGap(gap / 60 / 24 + "일 전");
					}

					if (cnt > 1000) {
						rlist.setCnt(cnt / 1000 + "천명");
					}

					if (title.length() > 45) {
						title = title.substring(0, 43) + "...";
						rlist.setTitle(title);
					}
					
					rlist.setContent(rlist.getContent().replace("\r\n", "<br>"));

				}
			}

			// 페이지 바 제작
			String pagebar = ""; // JSP 돌려줄 페이지 바 태그

			loop = 1; // 루프 변수(while)
			n = ((nowPage - 1) / blockSize) * blockSize + 1;// 페이지 번호

			pagebar += "<nav><ul class='pagination pagination-sm'>";

			// 이전 10페이지
			if (n == 1) {
				pagebar += String.format(
						" <li> <a href='#' aria-label='Previous'><span aria-hidden='true'>&laquo;</span> </a> </li>");
			} else {
				pagebar += String.format(
						" <li> <a href='/wmc/study/calendar/studycalendarlist.do?page=%d' aria-label='Previous'> <span aria-hidden='true'>&laquo;</span></a> </li>",
						n - 1);
			}

			while (!(loop > blockSize || n > totalPage)) {

				if (n == nowPage) {
					pagebar += String.format(" <li class='active'><a href='#'>%d</a></li>", n);
				} else {
					pagebar += String.format("<li><a href='/wmc/study/calendar/studycalendarlist.do?page=%d'>%d</a></li>", n, n);
				}

				loop++;
				n++;

			} // while

			if (n > totalPage) {
				pagebar += String.format(
						" <li> <a href='#' aria-label='Next'><span aria-hidden='true'>&raquo;</span> </a> </li> ");
			} else {
				pagebar += String.format(
						"<li> <a href='/wmc/study/calendar/studycalendarlist.do?page=%d' aria-label=\"Next\"> <span aria-hidden=\"true\">&raquo;</span> </a> </li>",
						n);
			}

			pagebar += "</ul>\r\n" + "		</nav>";

			req.setAttribute("calendarList", calendarList);
			
			req.setAttribute("pagebar", pagebar);
			req.setAttribute("totalCount", totalCount);
			req.setAttribute("totalPage", totalPage);
			req.setAttribute("nowPage", nowPage);
			req.setAttribute("grade", grade);
		}
		req.setAttribute("kind", kind);
		req.setAttribute("studyNum", studyNum);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/calendar/studycalendarlist.jsp");
		dispatcher.forward(req, resp);

	}

}

