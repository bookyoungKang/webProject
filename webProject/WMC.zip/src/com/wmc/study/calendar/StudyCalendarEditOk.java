package com.wmc.study.calendar;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 스터디 일정 수정하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/calendar/studycalendareditok.do")
public class StudyCalendarEditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		
		HttpSession session = req.getSession();

		String studyCalendarNum = req.getParameter("studyCalendarNum");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String kind = req.getParameter("kind");
		String begin = req.getParameter("beginYear") + "-" + req.getParameter("beginMonth") + "-" + req.getParameter("beginDay");
		String end = req.getParameter("endYear") + "-" + req.getParameter("endMonth") + "-" + req.getParameter("endDay"); 
		String place = req.getParameter("place");
		String lat = req.getParameter("lat");
		String lng = req.getParameter("lng");
		String id = session.getAttribute("certification").toString();
		
		StudyCalendarDTO dto = new StudyCalendarDTO();
		dto.setStudyCalendarNum(studyCalendarNum);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setKind(kind);
		dto.setBegin(begin);
		dto.setEnd(end);
		dto.setPlace(place);
		dto.setLat(lat);
		dto.setLng(lng);
		dto.setId(id);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter writer = resp.getWriter();

		StudyDAO dao = new StudyDAO();
		
		System.out.println("lat : " + dto.getLat());
		System.out.println("lng : " + dto.getLng());
		
		int result = dao.editCalendar(dto);
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('일정수정 실패!')");
			writer.println("history.back()");
		}else {
			writer.println("location.href='/wmc/study/calendar/studycalendarlist.do';");
		}
		writer.println("</script>");
		writer.close();
		

	}

}
