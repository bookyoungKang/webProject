package com.wmc.study;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;
import com.wmc.study.board.StudyBoardCommentDTO;
import com.wmc.study.board.StudyBoardDTO;
import com.wmc.study.calendar.StudyAttendDTO;
import com.wmc.study.calendar.StudyCalendarDTO;
import com.wmc.study.recruit.StudyRecruitCommentDTO;
import com.wmc.study.review.StudyReviewCommentDTO;
import com.wmc.study.review.StudyReviewDTO;

/**
 * 스터디 기능에서 DB 연동을 위한 클래스
 * @author bey15
 *
 */
public class StudyDAO {

	Connection conn;
	PreparedStatement pstat;
	ResultSet rs;

	/**
	 * DB 연동을 위한 초기 작업(생성자)
	 */
	public StudyDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}

	/**
	 * 스터디 모집에서 처음으로 보여줄 리스트를 가져오는 역할
	 * @param map 검색종류, 검색어, 가져올 데이터 수
	 * @return 스터디 리스트
	 */
	public ArrayList<StudyDTO> list(HashMap<String, String> map) {

		String condition = "";

		if (map.get("isSearch") != null) {
			condition = String.format("and %s like '%%%s%%'", map.get("kind"), map.get("txt"));

		}

		try {

			String sql = String.format(
					"select * from (select v.*, rownum as rnum from (select * from vwStudy  where del <> 0 and mdel = '1' order by StudyNum) v) where rnum between %s and %s %s",
					map.get("begin"), map.get("end"), condition);

			pstat = conn.prepareStatement(sql);

			rs = pstat.executeQuery();

			ArrayList<StudyDTO> list = new ArrayList<StudyDTO>();

			while (rs.next()) {

				StudyDTO dto = new StudyDTO();

				dto.setStudyNum(rs.getString("studyNum"));
				dto.setStudyName(rs.getString("studyName"));
				dto.setTitle(rs.getString("title"));
				dto.setId(rs.getString("id"));
				dto.setGap(rs.getString("gap"));
				dto.setCnt(rs.getString("cnt"));
				dto.setPersonnel(rs.getInt("personnel"));
				dto.setLimit(rs.getInt("limit"));

				list.add(dto);

			}

			return list;

		} catch (Exception e) {
			// TODO: handle exception
		}

		return null;
	}

	/**
	 * 스터디 모집 작성시 tblStudy 테이블에 들어갈 데이터
	 * @param dto 스터디를 생성하는 ID, 사용자이름, 제목, 내용, 정원
	 */
	public void addRecruit1(StudyDTO dto) {

		try {

			String sql = "insert into tblStudy (studyNum, id, studyName, title, content, limit) values (studyNum_seq.nextval, ?, ?, ?, ?, ?)";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getId());
			pstat.setString(2, dto.getStudyName());
			pstat.setString(3, dto.getTitle());
			pstat.setString(4, dto.getContent());
			pstat.setInt(5, dto.getLimit());

			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

	}

	/**
	 * 가장 최근에 추가된 스터디 시퀀스 가져오는 메소드
	 * @param id 사용자 아이디
	 */
	public void addRecruit2(String id) {

		try {

			String sql1 = "select max(studyNum) as num from tblStudy";

			pstat = conn.prepareStatement(sql1);
			rs = pstat.executeQuery();

			if (rs.next()) {

				String sql2 = "insert into tblStudyGroup (studyGroupNum, studyNum, id, grade) values (studyGroupNum_seq.nextval,?,?,3)";

				pstat = conn.prepareStatement(sql2);
				pstat.setString(1, rs.getString("num"));
				pstat.setString(2, id);

				pstat.executeUpdate();

			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

	}

	/**
	 * 스터디 정원을 가져오는 메소드
	 * @param id 해당 아이디
	 * @return 스터디 정원수
	 */
	public int addLimit(String id) {

		try {

			String sql = "select count(*) as cnt from tblStudyGroup where id = ? and del = 1";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);

			rs = pstat.executeQuery();

			if (rs.next()) {
				return Integer.parseInt(rs.getString("cnt"));
			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return 0;
	}

	/**
	 * 해당 스터디의 정보 가져오기
	 * @param studyNum 스터디 시퀀스 번호
	 * @return 스터디이름, 스터디장, 스터디 시퀀스 번호 등의 정보
	 */
	public StudyDTO vlist(String studyNum) {

		try {

			String sql = "select studyNum, id, studyName, title, content, (select name from tblMember where id = s.id) as name, limit, (select count(*) from tblStudyGroup where s.studyNum = tblStudyGroup.studyNum and tblStudyGroup.del = '1') as personnel from tblStudy s where studyNum = ?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);

			rs = pstat.executeQuery();

			if (rs.next()) {

				StudyDTO dto = new StudyDTO();
				dto.setStudyNum(rs.getString("studyNum"));
				dto.setId(rs.getString("id"));
				dto.setStudyName(rs.getString("studyName"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setName(rs.getString("name"));
				dto.setLimit(rs.getInt("limit"));
				dto.setPersonnel(rs.getInt("personnel"));

				return dto;

			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return null;
	}

	/**
	 * 해당 스터디에 해당하는 사람들의 id, 등급, 이름 가져오기
	 * @param studyNum 스터디 시퀀스 번호
	 * @return 스터디원들의 id, 등급, 이름
	 */
	public ArrayList<StudyGroupDTO> smlist(String studyNum) {

		try {

			String sql = "select sg.id as id, sg.grade as grade, m.name as name from tblStudyGroup sg inner join tblMember m on sg.id = m.id where studyNum = ? and sg.del = '1' order by sg.grade desc";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);

			rs = pstat.executeQuery();

			ArrayList<StudyGroupDTO> smlist = new ArrayList<StudyGroupDTO>();

			while (rs.next()) {
				StudyGroupDTO dto = new StudyGroupDTO();
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setGrade(rs.getString("grade"));

				smlist.add(dto);

			}

			return smlist;

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return null;
	}

	/**
	 *  스터디 참가하기
	 * @param id 로그인한 아이디
	 * @param studyNum 스터디 시퀀스 번호
	 * @return
	 */
	public int addStudyGroup(String id, String studyNum) {

		try {

			String sql2 = "insert into tblStudyGroup (studyGroupNum, studyNum, id, grade) values (studyGroupNum_seq.nextval, ?, ?, 1)";

			pstat = conn.prepareStatement(sql2);
			pstat.setString(1, studyNum);
			pstat.setString(2, id);
			System.out.println(id);
			System.out.println(studyNum);

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addStudyGroup : " + e.toString());
		}

		return 0;
	}

	/**
	 *  이미 가입한 스터디가 있는지를 확인
	 * @param id 로그인한 아이디
	 * @return 없으면 0 나머지는 있는거
	 */
	public int isGroup(String id) {

		try {

			String sql1 = "select count(*) as cnt from tblStudyGroup where id = ? and del = '1'";
			pstat = conn.prepareStatement(sql1);
			pstat.setString(1, id);

			rs = pstat.executeQuery();

			if (rs.next()) {
				int result = rs.getInt("cnt");
				return result;
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.isGroup : " + e.toString());
		}

		return 0;
	}

	/**
	 *  모집공고 수정
	 * @param dto 수정할 제목, 내용, 스터디시퀀스 번호, 스터디이름
	 * @return 성공 1 실패 0
	 */
	public int editRecruit(StudyDTO dto) {

		try {

			String sql = "update tblStudy set title=?, content=?, studyName=?, limit=? where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getTitle());
			pstat.setString(2, dto.getContent());
			pstat.setString(3, dto.getStudyName());
			pstat.setInt(4, dto.getLimit());
			pstat.setString(5, dto.getStudyNum());

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.editRecruit : " + e.toString());
		}

		return 0;
	}

	/**
	 *  모집공고 삭제
	 * @param studyNum 스터디 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delrecruit(String studyNum) {

		try {

			String sql = "update tblStudyGroup set del = '0' where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			pstat.executeUpdate();

			sql = "update tblStudyReview set del = '0' where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			pstat.executeUpdate();

			sql = "update tblStudyCalendar set del = '0' where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			pstat.executeUpdate();

			sql = "update tblStudyBoard set del = '0' where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			pstat.executeUpdate();

			sql = "update tblStudy set del = '0' where studyNum=?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delrecruit : " + e.toString());
		}

		return 0;
	}

	/**
	 *  스터디모집공고 조회수 추가
	 * @param studyNum 스터디 시퀀스 번호
	 */
	public void addCnt(String studyNum) {

		try {

			String sql = "update tblStudy set cnt = cnt+1 where studyNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);

			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addCnt : " + e.toString());
		}

	}

	/**
	 *  스터디 일정 가져오기
	 * @return 스터디 일정
	 */
	public ArrayList<StudyCalendarDTO> clist() {

		try {

			String sql = "select studyCalendarNum, to_char(begin, 'yyyy-mm-dd-si') as begin, to_char(end,'yyyy-mm-dd-si') as end, kind, place from tblStudyCalendar where del <> '0'";

			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();

			ArrayList<StudyCalendarDTO> clist = new ArrayList<StudyCalendarDTO>();

			while (rs.next()) {
				StudyCalendarDTO dto = new StudyCalendarDTO();

				dto.setStudyCalendarNum(rs.getString("studyCalendarNum"));
				dto.setBegin(rs.getString("begin"));
				dto.setEnd(rs.getString("end"));
				dto.setKind(rs.getString("kind"));
				dto.setPlace(rs.getString("place"));

				clist.add(dto);

			}

			return clist;

		} catch (Exception e) {
			System.out.println("StudyDAO.clist : " + e.toString());
		}

		return null;
	}

	/**
	 *  스터디전용 게시판 목록 불러오기
	 * @param map 검색조건, 리스트 개수
	 * @return 스터디 전용 게시판 목록
	 */
	public ArrayList<StudyBoardDTO> blist(HashMap<String, String> map) {

		try {

			String where = "";
			
			if(map.get("kind") != null && !map.get("kind").equals("전체보기")) {
				where = String.format("and kind = '%s'", map.get("kind"));
			}

			if(map.get("rating").equals("2")) {
				
				String sql = String.format("select a.* from(select b.*, rownum as rnum from(select studyBoardNum, studyNum, id, title, kind, content, round((sysdate-regdate)*24*60) as gap , cnt, notice from tblStudyBoard where del <> '0' order by notice desc,regdate desc, studyBoardNum) b) a where rnum between %s and %s %s",
					map.get("begin"), map.get("end"), where);
				
				pstat = conn.prepareStatement(sql);
				
			}else {
				
				String sql = String.format(
						"select a.* from(select b.*, rownum as rnum from(select studyBoardNum, studyNum, id, title, kind, content, round((sysdate-regdate)*24*60) as gap , cnt, notice from tblStudyBoard where del <> '0' and studyNum = ? or studyNum is null order by notice desc,regdate desc, studyBoardNum) b) a where rnum between %s and %s %s",
						map.get("begin"), map.get("end"), where);
	
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, map.get("studyNum"));
			}
			
			rs = pstat.executeQuery();

			ArrayList<StudyBoardDTO> blist = new ArrayList<StudyBoardDTO>();

			while (rs.next()) {

				StudyBoardDTO dto = new StudyBoardDTO();
				dto.setStudyBoardNum(rs.getString("studyBoardNum"));
				dto.setStudyNum(rs.getString("studyNum"));
				dto.setId(rs.getString("id"));
				dto.setTitle(rs.getString("title"));
				dto.setKind(rs.getString("kind"));
				dto.setContent(rs.getString("content"));
				dto.setGap(rs.getString("gap"));
				dto.setCnt(rs.getString("cnt"));
				dto.setNotice(rs.getString("notice"));
				
				blist.add(dto);

			}

			return blist;

		} catch (Exception e) {
			System.out.println("StudyDAO.blist : " + e.toString());
		}

		return null;
	}

	/**
	 *  스터디를 알기 위해 스터디번호를 가져오기
	 * @param id 로그인한 아이디
	 * @return 가입한 스터디번호
	 */
	public String getStudyNum(String id) {

		try {

			String sql = "select studyNum from tblStudyGroup where id = ? and del <> '0'";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);

			rs = pstat.executeQuery();
			if (rs.next()) {

				String studyNum = rs.getString("studyNum");

				return studyNum;

			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getStudyNum : " + e.toString());
		}

		return null;
	}

	/**
	 *  스터디 전용게시판 추가
	 * @param dto 게시판 제목, 작성자, 내용  등의 추가할 데이터
	 * @return 성공 1 실패 0
	 */
	public int addBoard(StudyBoardDTO dto) {

		try {

			String rating = "0";
			
			if(dto.getRating().equals("2")) {
				rating = "1";
			}
			
			String sql = "insert into tblStudyBoard (studyBoardNum, studyNum, id, title, kind, content, regdate, cnt, del, notice) values(studyBoardNum_seq.nextval, ?, ?, ?, ?, ?, default, default, '1', '" + rating + "')"; // 마지막은
																																																					// 공지여부,
																																																					// 공지할
																																																					// 때
																																																					// 고쳐야됨

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getTitle());
			
			if(dto.getRating().equals("2")) {
				pstat.setString(4, "공지");
			}else {
				
				pstat.setString(4, dto.getKind());
			}
			pstat.setString(5, dto.getContent());

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addBoard : " + e.toString());
		}

		return 0;
	}

	/**
	 *  스터디 전용 게시판 정보 가져오기
	 * @param studyBoardNum 스터디 전용 게시판 시퀀스 번호
	 * @return 스터디 전용 게시판 정보
	 */
	public StudyBoardDTO bvlist(String studyBoardNum) {

		try {

			String sql = "select studyBoardNum, studyNum, id, content, title, kind from tblStudyBoard where studyBoardNum = ?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardNum);
			rs = pstat.executeQuery();

			StudyBoardDTO dto = new StudyBoardDTO();

			if (rs.next()) {

				dto.setStudyBoardNum(rs.getString("studyBoardNum"));
				dto.setStudyNum(rs.getString("studyNum"));
				dto.setId(rs.getString("id"));
				dto.setContent(rs.getString("content"));
				dto.setTitle(rs.getString("title"));
				dto.setKind(rs.getString("kind"));

			}

			return dto;

		} catch (Exception e) {
			System.out.println("StudyDAO.bvlist : " + e.toString());
		}

		return null;
	}

	/**
	 *  스터디 전용게시판 수정
	 * @param dto 수정할 내용, 제목, 종류, 스터디 전용게시판 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int editBoard(StudyBoardDTO dto) {

		try {

			String sql = "update tblStudyBoard set title = ?, content = ?, kind = ? where studyBoardNum = ?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getTitle());
			pstat.setString(2, dto.getContent());
			pstat.setString(3, dto.getKind());
			pstat.setString(4, dto.getStudyBoardNum());

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.editBoard : " + e.toString());
		}

		return 0;
	}

	/**
	 *  스터디전용 게시판 삭제하기
	 * @param studyBoardNum 스터디 전용 게시판 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delBoard(String studyBoardNum) {

		try {

			String sql = "update tblStudyBoard set del = '0' where studyBoardNum = ?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardNum);

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delBoard : " + e.toString());
		}

		return 0;
	}

	/**
	 *  스터디모집공고 게시물 개수 가져오기
	 * @param map 검색조건, 가져올 개수
	 * @return 스터디모집공고 게시물
	 */
	public int getTotalCountRecruit(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch") != null && map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'", map.get("kind"), map.get("txt"));
			}
			String sql = String.format("select count(*) as cnt from tblStudy where del <> 0 %s", where);
			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getTotalCountRecruit : " + e.toString());
		}

		return 0;
	}

	/**
	 *  스터디 전용 게시판 게시물 수를 가져오기
	 * @param map 검색조건, 개수
	 * @return 스터디 전용 게시판 게시물 수
	 */
	public int getTotalCountBoard(HashMap<String, String> map) {

		try {

			String where = "";
			if(map.get("kind") != null && !map.get("kind").equals("전체보기")) {
				where = String.format("and kind = '%s'", map.get("kind"));
			}
			
			
			String sql = String.format("select count(*) as cnt from tblStudyBoard where del <> 0 %s", where);
			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getTotalCountBoard : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 전용 게시판 조회수 추가
	 * @param studyBoardNum 스터디 전용 게시판 시퀀스 번호
	 */
	public void addCntBoard(String studyBoardNum) {
		
		try {

			String sql = "update tblStudyBoard set cnt = cnt+1 where studyBoardNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardNum);
			
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addCntBoard : " + e.toString());
		}
		
	}

	/**
	 *  스터디 등급 가져오기
	 * @param id 접속한 아이디
	 * @return 스터디 등급
	 */
	public String studyGrade(String id) {
		
		try {

			String sql = "select grade from tblStudyGroup where id = ? and del = 1";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			
			rs = pstat.executeQuery();
			
			// 스터디가 하나밖에 들 수 없도록 설정하였기 때문에 최대 한개만 들어있음
			if(rs.next()) {
				return rs.getString("grade");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.studyGrade : " + e.toString());
		}
		
		return null;
	}

	/**
	 *  스터디 등급 변경하기
	 * @param id 스터디원 아이디
	 * @param grade 스터디 등급
	 * @return 성공 1 실패 0
	 */
	public int studyUpdate(String id, String grade) {
		
		try {

			String sql = "update tblStudyGroup set grade = ? where id = ? and del = '1'";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, grade);
			pstat.setString(2, id);
			
			return pstat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("StudyDAO.studyUpdate : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 모집공고 댓글 수 가져오기
	 * @param studyNum 스터디 모집공고 시퀀스 번호
	 * @return 스터디 모집공고 댓글 수
	 */
	public int countRecruitComment(String studyNum) {
		
		try {

			String sql = "select count(*) as cnt from tblStudyComment where studyNum = ? and del = '1'";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				return Integer.parseInt(rs.getString("cnt"));
				
			}
			
		} catch (Exception e) {
			System.out.println("StudyDAO.countRecruitComment : " + e.toString());
		}
		
		return 0;
		
	}

	/**
	 *  스터디 모집하기 글 삭제
	 * @param id 로그인한 아이디
	 */
	public void studyDel(String id) {
		
		try {

			String sql = "update tblStudy set del = '0' where id = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.studyDel : " + e.toString());
		}
		
	}

	/**
	 *  스터디 모집하기 댓글 작성
	 * @param dto 댓글 내용, 작성자 등 정보
	 * @return 성공 1 실패 0
	 */
	public int addStudyComment(StudyRecruitCommentDTO dto) {
		
		try {

			String sql = "insert into tblStudyComment (studyCommentNum, studyNum, id, content, del, regdate) values (studyCommentNum_seq.nextval, ?, ?, ?, '1', default)";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getContent());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addStudyComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 모집하기 댓글 작성 시간가져오기
	 * @return 댓글 작성 시간
	 */
	public String getRegdate() {
		
		try {

			String sql = "select to_char(max(regdate), 'yyyy-mm-dd hh:mi:ss') as regdate from tblStudyComment";

			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getString("regdate");
				
			}
			
		} catch (Exception e) {
			System.out.println("StudyDAO.getRegdate : " + e.toString());
		}
		
		return null;
	}

	/**
	 *  해당 게시물의 댓글을 가져오기 위한 메소드
	 * @param studyNum 스터디 시퀀스 번호
	 * @return 게시물 댓글 목록
	 */
	public ArrayList<StudyRecruitCommentDTO> rclist(String studyNum) {
		
		try {

			String sql = "select StudyCommentNum, content, id, to_char(regdate, 'yyyy-mm-dd hh:mi:ss') as regdate from tblStudyComment where studyNum = ? and del = '1' order by studyCommentNum desc";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyNum);
			rs = pstat.executeQuery();
			
			ArrayList<StudyRecruitCommentDTO> rclist = new ArrayList<StudyRecruitCommentDTO>();
			
			while(rs.next()) {
				
				StudyRecruitCommentDTO dto = new StudyRecruitCommentDTO();
				
				dto.setStudyCommentNum(rs.getString("StudyCommentNum"));
				dto.setContent(rs.getString("content").replace("\r\n", "<br>"));
				dto.setId(rs.getString("id"));
				dto.setRegdate(rs.getString("regdate"));
			
				rclist.add(dto);
			}
			
			return rclist;
			

		} catch (Exception e) {
			System.out.println("StudyDAO.rclist : " + e.toString());
		}
		
		return null;
	}

	/**
	 *  스터디 모집하기 댓글 수정
	 * @param dto 수정할 댓글 내용, 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int updateStudyComment(StudyRecruitCommentDTO dto) {
		
		try {

			String sql = "update tblStudyComment set content = ? where studyCommentNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getContent());
			pstat.setString(2, dto.getStudyCommentNum());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.updateStudyComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 모집하기 댓글 삭제
	 * @param studyCommentNum 스터디 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delStudyComment(String studyCommentNum) {
		
		try {

			String sql = "update tblStudyComment set del = '0' where studyCommentNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyCommentNum);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delStudyComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디전용게시판 댓글 개수 가져오기
	 * @param studyBoardNum 스터디전용게시판 시퀀스 번호
	 * @return 댓글 개수
	 */
	public int countBoardComment(String studyBoardNum) {
		
		try {

			String sql = "select count(*) as cnt from tblStudyBoardComment where studyBoardNum = ? and del = '1'";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardNum);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				return Integer.parseInt(rs.getString("cnt"));
				
			}
			

		} catch (Exception e) {
			System.out.println("StudyDAO.countBoardComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디전용게시판 댓글 리스트 가져오기
	 * @param studyBoardNum 스터디전용 게시판 시퀀스 번호
	 * @return 댓글 목록
	 */
	public ArrayList<StudyBoardCommentDTO> studyBoardCommentlist(String studyBoardNum) {
		
		try {

			String sql = "select studyBoardCommentNum, id, content, regdate from tblStudyBoardComment where studyBoardNum = ? and del = '1' order by studyBoardCommentNum desc";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardNum);
			rs = pstat.executeQuery();
			
			ArrayList<StudyBoardCommentDTO> list = new ArrayList<StudyBoardCommentDTO>();
			
			while(rs.next()) {
				
				StudyBoardCommentDTO dto = new StudyBoardCommentDTO();
				dto.setStudyBoardCommentNum(rs.getString("studyBoardCommentNum"));
				dto.setId(rs.getString("id"));
				dto.setContent(rs.getString("content"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
				
			}
			
			return list;

		} catch (Exception e) {
			System.out.println("StudyDAO.studyBoardCommentlist : " + e.toString());
		}
		
		return null;
	}

	/**
	 *  스터디 전용 게시판 댓글 추가하기
	 * @param dto 추가할 댓글 내용, 아이디 등의 정보
	 * @return 성공 1 실패 0
	 */
	public int addStudyBoardComment(StudyBoardCommentDTO dto) {
		
		try {

			String sql = "insert into tblStudyBoardComment (studyBoardCommentNum, studyBoardNum, id, content, regdate, del) values (studyBoardCommentNum_seq.nextval, ?, ?, ?, default, default)";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyBoardNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getContent());
			
			return pstat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("StudyDAO.addStudyBoardComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 전용 게시판 댓글 삭제하기
	 * @param studyBoardCommentNum 스터디 전용 게시판 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delStudyBoardComment(String studyBoardCommentNum) {
		
		try {

			String sql = "update tblStudyBoardComment set del = '0' where studyBoardCommentNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyBoardCommentNum);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delStudyBoardComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 * 스터디 전용 게시판 댓글 수정하기
	 * @param dto 수정할 댓글 내용, 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int updateStudyBoardComment(StudyBoardCommentDTO dto) {
		
		try {

			String sql = "update tblStudyBoardComment set content = ? where studyBoardCommentNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getContent());
			pstat.setString(2, dto.getStudyBoardCommentNum());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.updateStudyBoardComment : " + e.toString());
		}
		
		return 0;
	}

	/**
	 * 스터디 후기 게시판 목록 가져오기
	 * @param map 검색조건, 개수
	 * @return 스터디 후기 게시판 목록
	 */
	public ArrayList<StudyReviewDTO> srlist(HashMap<String, String> map) {

		String condition = "";

		if (map.get("isSearch") != null) {
			condition = String.format("where %s like '%%%s%%'", map.get("kind"), map.get("txt"));

		}

		try {

			String sql = String.format(
					"select sr.* from (select studyReviewNum,id,studyNum, title, content, gap, cnt, notice,studyName, rownum as rnum from (select * from vwStudyReview %s order by studyReviewNum desc) s) sr where rnum between %s and %s", 
					condition, map.get("begin"), map.get("end"));

			pstat = conn.prepareStatement(sql);

			rs = pstat.executeQuery();

			ArrayList<StudyReviewDTO> list = new ArrayList<StudyReviewDTO>();

			while (rs.next()) {

				StudyReviewDTO dto = new StudyReviewDTO();

				dto.setStudyReviewNum(rs.getString("studyReviewNum"));
				dto.setId(rs.getString("id"));
				dto.setStudyNum(rs.getString("studyNum"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setGap(rs.getString("gap"));
				dto.setCnt(rs.getString("cnt"));
				dto.setNotice(rs.getString("notice"));
				dto.setStudyName(rs.getString("studyName"));

				list.add(dto);

			}

			return list;

		} catch (Exception e) {
			// TODO: handle exception
		}

		return null;

	}

	/**
	 * 스터디 후기 게시판 게시글 추가하기
	 * @param dto 추가할 게시글의 제목, 내용 등의 정보
	 */
	public void addReview(StudyReviewDTO dto) {

		try {

			String sql = "insert into tblStudyReview (studyReviewNum, id, studyNum, title, content, regdate, cnt, del, notice) values(studyReviewNum_seq.nextval, ?, ?, ?, ?, default, default, default, default)";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getId());
			pstat.setString(2, dto.getStudyNum());
			pstat.setString(3, dto.getTitle());
			pstat.setString(4, dto.getContent());

			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addReview : " + e.toString());
		}

	}

	/**
	 * 스터디 후기 게시글 총 개수
	 * @param map 검색 조건
	 * @return 스터디 후기 게시글 총 개수
	 */
	public int getTotalCountReview(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch") != null && map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'", map.get("kind"), map.get("txt"));
			}
			String sql = String.format("select count(*) as cnt from tblStudyReview where del <> 0 %s", where);
			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getTotalCountRecruit : " + e.toString());
		}

		return 0;
	}

	/**
	 * 스터디 리뷰 게시판의 상세보기 목록 가져오기
	 * @param studyReviewNum 스터디 리뷰 게시판의 시퀀스 번호
	 * @return
	 */
	public StudyReviewDTO rvlist(String studyReviewNum) {

		try {

			String sql = "select studyReviewNum, id, title, content, studyName from vwStudyReview where studyReviewNum = ?";

			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewNum);
			rs = pstat.executeQuery();

			// studyReviewNum은 primary key 이므로 하나밖에 안나옴
			if (rs.next()) {

				StudyReviewDTO dto = new StudyReviewDTO();

				dto.setStudyReviewNum(rs.getString("studyReviewNum"));
				dto.setId(rs.getString("id"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setStudyName(rs.getString("studyName"));

				return dto;

			}

		} catch (Exception e) {
			System.out.println("StudyDAO.rvlist : " + e.toString());
		}

		return null;
	}

	/**
	 * 스터디 후기 게시판의 조회수 증가
	 * @param studyReviewNum 스터디 후기 게시판 시퀀스 번호
	 */
	public void addReviewCnt(String studyReviewNum) {

		try {

			String sql = "update tblStudyReview set cnt = cnt+1 where studyReviewNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewNum);

			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addCnt : " + e.toString());
		}

	}

	/**
	 * 스터디 리뷰 게시판의 댓글 개수 가져오기
	 * @param studyReviewNum 스터디 리뷰 게시판의 시퀀스 번호
	 * @return 댓글 개수
	 */
	public int countReviewComment(String studyReviewNum) {
		
		try {

			String sql = "select count(*) as cnt from tblStudyReviewComment where studyReviewNum=? and del = '1'";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewNum);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				return rs.getInt("cnt");
			}
			

		} catch (Exception e) {
			System.out.println("StudyDAO.countReviewComment : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 리뷰 게시판의 댓글 목록 가져오기
	 * @param studyReviewNum 스터디 리뷰 게시판의 시퀀스 번호
	 * @return 댓글 목록
	 */
	public ArrayList<StudyReviewCommentDTO> ReviewCommentlist(String studyReviewNum) {
		
		try {

			String sql = "select studyReviewCommentNum, id, content, regdate from tblStudyReviewComment where studyReviewNum=? and del='1' order by studyReviewCommentNum desc";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewNum);
			
			rs = pstat.executeQuery();
			
			ArrayList<StudyReviewCommentDTO> list = new ArrayList<StudyReviewCommentDTO>();
			
			while(rs.next()) {
				
				StudyReviewCommentDTO dto = new StudyReviewCommentDTO();
				dto.setStudyReviewCommentNum(rs.getString("studyReviewCommentNum"));
				dto.setStudyReviewNum(rs.getString("studyReviewCommentNum"));
				dto.setId(rs.getString("id"));
				dto.setContent(rs.getString("content"));
				dto.setRegdate(rs.getString("regdate"));
				
				list.add(dto);
				
			}
			
			return list;

		} catch (Exception e) {
			System.out.println("StudyDAO.ReviewCommentlist : " + e.toString());
		}

		
		return null;
	}

	/**
	 * 스터디 후기게시판의 게시글 수정하기
	 * @param dto 수정할 제목, 내용, 게시글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int editReview(StudyReviewDTO dto) {
		
		try {

			String sql = "update tblStudyReview set title = ?, content = ? where studyReviewNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getTitle());
			pstat.setString(2, dto.getContent());
			pstat.setString(3, dto.getStudyReviewNum());

			return pstat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("StudyDAO.editReview : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기 게시글의 댓글 삭제하기
	 * @param studyReviewNum 게시글의 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delReview(String studyReviewNum) {
		
		try {

			String sql = "update tblStudyReview set del = '0' where studyReviewNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewNum);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delReview : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기 게시판의 댓글 추가하기
	 * @param dto 추가할 댓글 내용, 게시글 시퀀스 번호, 로그인한 아이디
	 * @return 성공 1 실패 0
	 */
	public int addReviewCommentAdd(StudyReviewCommentDTO dto) {
		
		try {

			String sql = "insert into tblStudyReviewComment  (studyReviewCommentNum, studyReviewNum, id, content, regdate, del) values (studyReviewCommentNum_seq.nextval, ?, ?, ?, default, default)";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyReviewNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getContent());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addReviewCommentAdd : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기게시판의 마지막 추가한 시퀀스 번호 가져오기
	 * @return 마지막 시퀀스 번호
	 */
	public int getReviewCommentLastNum() {
		
		try {

			String sql = "select max(studyReviewCommentNum) as num from tblStudyReviewComment";
			
			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("num");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getReviewCommentLastNum : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기 게시판의 마지막 댓글 정보 가져오기
	 * @param lastNum 스터디 후기 게시판의 마지막 시퀀스 번호
	 * @return 마지막 댓글 정보
	 */
	public StudyReviewCommentDTO getReviewComment(int lastNum) {
		
		try {

			String sql = "select studyReviewCommentNum, id, content, regdate from tblStudyReviewComment where studyReviewCommentNum = ? ";

			pstat = conn.prepareStatement(sql);
			pstat.setInt(1, lastNum);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				StudyReviewCommentDTO dto = new StudyReviewCommentDTO();
				
				dto.setStudyReviewNum(rs.getString("studyReviewCommentNum"));
				dto.setId(rs.getString("id"));
				dto.setContent(rs.getString("content"));
				dto.setRegdate(rs.getString("regdate"));
				
				return dto;
				
			}
			
			
			
		} catch (Exception e) {
			System.out.println("StudyDAO.getReviewComment : " + e.toString());
		}

		
		return null;
	}

	/**
	 *  스터디 일정 리스트 뽑아오기
	 * @param map 검색조건, 개수
	 * @return 스터디 일정
	 */
	public ArrayList<StudyCalendarDTO> CalendarList(HashMap<String, String> map) {
		
		try {

			String where = "";
			String studyNum = "and studyNum = ?";
			
			if(map.get("rating").equals("2")) {
				studyNum = "";
			}

			if (map.get("kind") != null && !map.get("kind").equals("전체보기")) {
				where = String.format("and kind = '%s'", map.get("kind"));
			}
			
			String sql = String.format("select b.* from (select a.*, rownum as rnum from (select studyCalendarNum, studyNum, id, title, content, begin, end, kind, place, lat, lng, round((sysdate-regdate)*24*60) as gap, cnt , (select count(*) from tblAttend where id = '%s' and studyCalendarNum = c.studyCalendarNum) as attendcnt from tblStudyCalendar c where del = '1' %s %s order by begin desc) a) b where rnum between %s and %s",map.get("id"), studyNum, where, map.get("begin"), map.get("end"));
			
			pstat = conn.prepareStatement(sql);
			
			
			if(!map.get("rating").equals("2")) {
				pstat.setString(1, map.get("studyNum"));
			}
			
			rs = pstat.executeQuery();
			
			ArrayList<StudyCalendarDTO> list = new ArrayList<StudyCalendarDTO>();
			
			while(rs.next()) {
				
				StudyCalendarDTO dto = new StudyCalendarDTO();
				dto.setStudyCalendarNum(rs.getString("studyCalendarNum"));
				dto.setStudyNum(rs.getString("studyNum"));
				dto.setId(rs.getString("id"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setBegin(rs.getString("begin").substring(0,10));
				dto.setEnd(rs.getString("end").substring(0,10));
				dto.setKind(rs.getString("kind"));
				dto.setPlace(rs.getString("place"));
				dto.setLat(rs.getString("lat"));
				dto.setLng(rs.getString("lng"));
				dto.setGap(rs.getString("gap"));
				dto.setCnt(rs.getString("cnt"));
				dto.setAttendcnt(rs.getInt("attendcnt"));
				
				// 일정번호 뽑아오기, 각 캘린더 일정에서 참가했는지 여부 확인을 위해
//				String attendNum = getAttendNum(map.get("id"), dto.getStudyCalendarNum()); 
//				dto.setAttendNum(attendNum);
				
				list.add(dto);
				
			}
			
			return list;
					

		} catch (Exception e) {
			System.out.println("StudyDAO.CalendarList : " + e.toString());
		}

		
		return null;
	}

	/**
	 * 스터디일정 참석자 수 가져오기
	 * @param id 로그인한 아이디
	 * @param studyCalendarNum 스터디 일정 시퀀스 번호
	 * @return 일정에 참석자 수
	 */
	private String getAttendNum(String id, String studyCalendarNum) {
		
		try {

			String sql = "select count(*) as cnt from tblAttend where id = ? and studyCalendarNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			pstat.setString(2, studyCalendarNum);
			rs = pstat.executeQuery();
			
			// 일정 참여는 한번밖에 못함
			if(rs.next()) {
				return rs.getString("cnt");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getAttendNum : " + e.toString());
		}

		
		return null;
	}

	/**
	 *  스터디 일정 개수 뽑아오기
	 * @param map 검색조건
	 * @return 스터디 일정 개수
	 */
	public int getTotalCountCalendar(HashMap<String, String> map) {
		
		try {

			String where = "";
			if (map.get("kind") != null && !map.get("kind").equals("전체보기")) {
				where = String.format("and kind = '%s'", map.get("kind"));
			}

			String sql = String.format("select count(*) as cnt from tblStudyCalendar where del <> 0 %s", where);
			pstat = conn.prepareStatement(sql);
			rs = pstat.executeQuery();
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("StudyDAO.getTotalCountBoard : " + e.toString());
		}
		
		return 0;
	}

	/**
	 *  스터디 일정 추가하기
	 * @param dto 추가할 스터디 일정 정보
	 * @return 성공 1 실패 0
	 */
	public int addCalendar(StudyCalendarDTO dto) {
		
		try {

			String sql = "insert into tblStudyCalendar (studyCalendarNum, studyNum, id, title, content, begin, end, kind, del, place, lat, lng, regdate, cnt) values (studyCalendarNum_seq.nextval, ?, ?, ?, ?, ?, ?, ?, default, ?, ?, ?, default, default)";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getTitle());
			pstat.setString(4, dto.getContent());
			pstat.setString(5, dto.getBegin());
			pstat.setString(6, dto.getEnd());
			pstat.setString(7, dto.getKind());
			pstat.setString(8, dto.getPlace());
			pstat.setString(9, dto.getLat());
			pstat.setString(10, dto.getLng());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addCalendar : " + e.toString());
		}

		
		return 0;
	}

	/**
	 *  스터디 등급 뽑아오기
	 * @param id 로그인한 아이디
	 * @return 스터디 등급
	 */
	public String getStudyGrade(String id) {
		
		try {

			String sql = "select grade from tblStudyGroup where id = ? and del = '1'";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			rs = pstat.executeQuery();
			
			// 스터디는 한개밖에 못들기 때문에 등급은 하나임
			if(rs.next()) {
				return rs.getString("grade");
			}
			

		} catch (Exception e) {
			System.out.println("StudyDAO.getStudyGrade : " + e.toString());
		}

		
		return null;
	}

	/**
	 *  스터디 일정 편집에서 채워넣을 정보 가져오기
	 * @param studyCalendarNum 스터디 일정 시퀀스 번호
	 * @return 스터디 일정 정보
	 */
	public StudyCalendarDTO getStudyCalendar(String studyCalendarNum) {
		
		try {

			String sql = "select kind, begin, end, place, lat, lng, title, content from tblStudyCalendar where studyCalendarNum = ? and del = '1'";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyCalendarNum);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				StudyCalendarDTO dto = new StudyCalendarDTO();
				
				dto.setKind(rs.getString("kind"));
				dto.setBegin(rs.getString("begin"));
				dto.setEnd(rs.getString("end"));
				dto.setPlace(rs.getString("place"));
				dto.setLat(rs.getString("lat"));
				dto.setLng(rs.getString("lng"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				
				return dto;
				
			}
			

		} catch (Exception e) {
			System.out.println("StudyDAO.getStudyCalendar : " + e.toString());
		}

		
		return null;
	}

	/**
	 * 스터디 일정 수정하기
	 * @param dto 수정할 스터디 일정 정보
	 * @return 성공 1 실패 0
	 */
	public int editCalendar(StudyCalendarDTO dto) {
		
		try {
			
			String sql = "update tblStudyCalendar set title = ?, content = ?, kind = ?, begin = ?, end = ?, place = ?, lat = ?, lng = ? where studyCalendarNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getTitle());
			pstat.setString(2, dto.getContent());
			pstat.setString(3, dto.getKind());
			pstat.setString(4, dto.getBegin());
			pstat.setString(5, dto.getEnd());
			pstat.setString(6, dto.getPlace());
			pstat.setString(7, dto.getLat());
			pstat.setString(8, dto.getLng());
			pstat.setString(9, dto.getStudyCalendarNum());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.editCalendar : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 일정 삭제하기
	 * @param studyCalendarNum 스터디 일정 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delStudyCalendar(String studyCalendarNum) {
		
		try {

			String sql = "update tblStudyCalendar set del = '0' where studyCalendarNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyCalendarNum);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delStudyCalendar : " + e.toString());
		}

		
		return 0;
	}

	/**
	 *  일정에 참석
	 * @param dto 스터디 일정 시퀀스 번호, 로그인한 아이디
	 * @return 성공 1 실패 0
	 */
	public int addAttend(StudyAttendDTO dto) {
		
		try {

			String sql = "insert into tblAttend (studyAttendNum, studyCalendarNum, id) values (studyAttendNum_seq.nextval, ?, ?)";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyCalendarNum());
			pstat.setString(2, dto.getId());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addAttend : " + e.toString());
		}

		
		return 0;
	}

	/**
	 *  일정에 참가한 인원들 뽑아오기
	 * @param studyCalendarNum 스터디 일정 시퀀스 번호
	 * @return 일정 참가 인원 정보
	 */
	public ArrayList<StudyAttendDTO> getAttend(String studyCalendarNum) {
		
		try {

			String sql = "select a.id as id, m.name as name from tblAttend a  inner join tblMember m on a.id = m.id where a.studyCalendarNum = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyCalendarNum);
			rs = pstat.executeQuery();
			
			ArrayList<StudyAttendDTO> list = new ArrayList<StudyAttendDTO>();
			
			while(rs.next()) {
				
				StudyAttendDTO dto = new StudyAttendDTO();
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				
				list.add(dto);
				
			}
			
			return list;

		} catch (Exception e) {
			System.out.println("StudyDAO.getAttend : " + e.toString());
		}

		
		return null;
	}

	/**
	 * 일정 참가 취소하기
	 * @param dto 로그인한 아이디, 일정 취소할 스터디 일정 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delAttend(StudyAttendDTO dto) {
		
		try {

			String sql = "delete from tblAttend where id = ? and studyCalendarNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getId());
			pstat.setString(2, dto.getStudyCalendarNum());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delAttend : " + e.toString());
		}
		
		return 0;
	}

	/**
	 * 스터디 후기 게시판 댓글 추가하기
	 * @param dto 추가할 댓글 정보
	 * @return 성공 1 실패 0
	 */
	public int addStudyReviewComment(StudyReviewCommentDTO dto) {
		
		
		try {

			String sql = "insert into tblStudyReviewComment (studyReviewCommentNum, studyReviewNum, id, content, regdate, del) values (studyReviewCommentNum_seq.nextval, ?, ?, ?, default, default)";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getStudyReviewNum());
			pstat.setString(2, dto.getId());
			pstat.setString(3, dto.getContent());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.addStudyReviewComment : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기 게시판 댓글 수정
	 * @param dto 수정할 댓글 정보
	 * @return 성공 1 실패 0
	 */
	public int updateStudyReviewComment(StudyReviewCommentDTO dto) {
		
		
		try {

			String sql = "update tblStudyReviewComment set content = ? where studyReviewCommentNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getContent());
			pstat.setString(2, dto.getStudyReviewCommentNum());
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.updateStudyReviewComment : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 후기 댓글 삭제
	 * @param studyReviewCommentNum 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delStudyReviewComment(String studyReviewCommentNum) {
		
		try {

			String sql = "update tblStudyReviewComment set del = '0' where studyReviewCommentNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, studyReviewCommentNum);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delStudyReviewComment : " + e.toString());
		}

		
		return 0;
	}

	/**
	 * 스터디 탈퇴하기
	 * @param id 로그인한 아이디
	 * @return 성공 1 실패 0
	 */
	public int studyWithdrawal(String id) {

		try {

			String sql = "update tblStudyGroup set del = '0' where id = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			
			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.studyWithdrawal : " + e.toString());
		}
		
		return 0;

		
	}

	/**
	 * 등록된 스터디가 있는지 확인하기
	 * @param id 로그인한 아이디
	 * @return 스터디가 있으면 1 없으면 0
	 */
	public int getStudyGroupNum(String id) {
		
		try {

			String sql = "select count(*) as cnt from tblStudyGroup where del = '1' and id = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			rs = pstat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("cnt");
				
			}
			
			

		} catch (Exception e) {
			System.out.println("StudyDAO.getStudyGroupNum : " + e.toString());
		}

		
		return 0;
	}

	/**
	 *  스터디가 없어질 경우 해당 스터디원들이 탈퇴하게 함
	 * @param num 스터디 시퀀스 번호
	 */
	public void delStudyGroup(String num) {

		try {

			String sql = "update tblStudyGroup set del = '0' where studyNum = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, num);
			
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delStudyGroup : " + e.toString());
		}

		
	}

	/**
	 * 해당 아이디가 작성한 스터디모집공고 글 삭제하기
	 * @param id 로그인한 아이디
	 */
	public void delrecruitStudy(String id) {
		
		try {

			String sql = "update tblStudy set del = '0' where id = ?";
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delrecruitStudy : " + e.toString());
		}
		
	}

	/**
	 * 해당아이디가 가입한 스터디 탈퇴하기
	 * @param id 로그인한 아이디
	 */
	public void delrecruitStudyGroup(String id) {
		
		try {

			String sql = "update tblStudyGroup set del = '0' where id = ?";
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, id);
			pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println("StudyDAO.delrecruitStudyGroup : " + e.toString());
		}
		
	}

}
