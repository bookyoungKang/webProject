package com.wmc.study.review;

/**
 * 스터디 후기 게시판 댓글 정보를 담을 클래스
 * @author bey15
 *
 */
public class StudyReviewCommentDTO {

	private String studyReviewCommentNum;
	private String studyReviewNum;
	private String id;
	private String content;
	private String regdate;
	
	public String getStudyReviewCommentNum() {
		return studyReviewCommentNum;
	}
	public void setStudyReviewCommentNum(String studyReviewCommentNum) {
		this.studyReviewCommentNum = studyReviewCommentNum;
	}
	public String getStudyReviewNum() {
		return studyReviewNum;
	}
	public void setStudyReviewNum(String studyReviewNum) {
		this.studyReviewNum = studyReviewNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	
	
}
