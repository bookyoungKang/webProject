package com.wmc.study.review;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

/**
 *  스터디 후기 게시판 작성하기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/review/studyreviewaddok.do")
public class StudyReviewAddOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");

		HttpSession session = req.getSession();
		
		StudyDAO dao = new StudyDAO();

		String id = session.getAttribute("certification").toString();
		String rating = session.getAttribute("rating").toString();
		
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String studyNum = dao.getStudyNum(id);


		StudyReviewDTO dto = new StudyReviewDTO();
		dto.setId(id);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setStudyNum(studyNum);

		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter writer = resp.getWriter();

		writer.println("<script>");

		// studyNum 이 0으로 시작하는 스터디는 없음, 스터디가 존재하지 않을 때 0
		if (studyNum != null && !studyNum.equals("") && !rating.equals("2")) {
			dao.addReview(dto);
			writer.println("location.href='/wmc/study/review/studyreviewlist.do';");
		} else {
			writer.println("alert('가입된 스터디가 없어 작성이 불가합니다.!')");
			writer.println("history.back()");
		}

		writer.println("</script>");

		writer.close();

	}

}