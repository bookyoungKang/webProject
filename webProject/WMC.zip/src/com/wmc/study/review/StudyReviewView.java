package com.wmc.study.review;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;
import com.wmc.study.StudyGroupDTO;
import com.wmc.study.recruit.StudyRecruitCommentDTO;

/**
 *  스터디 후기 게시판 상세보기 클래스
 * @author bey15
 *
 */
@WebServlet("/study/review/studyreviewview.do")
public class StudyReviewView extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();

		String studyReviewNum = req.getParameter("studyReviewNum");
		String id = session.getAttribute("certification").toString();

		StudyDAO dao = new StudyDAO();
		StudyReviewDTO dto = dao.rvlist(studyReviewNum); // 스터디 리뷰 상세보기 정보 가져오기
		
		dao.addReviewCnt(studyReviewNum); // 조회수 추가
		
		int commentCnt = dao.countReviewComment(studyReviewNum); // 댓글 수
		ArrayList<StudyReviewCommentDTO> rclist = dao.ReviewCommentlist(studyReviewNum); // 댓글 리스트

		dto.setContent(dto.getContent().replace("\r\n", "<br>"));

		req.setAttribute("dto", dto);
		req.setAttribute("rclist", rclist);
		req.setAttribute("commentCnt", commentCnt);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/review/studyreview.jsp");
		dispatcher.forward(req, resp);

	}

}