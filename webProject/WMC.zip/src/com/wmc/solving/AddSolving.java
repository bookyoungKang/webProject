package com.wmc.solving;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 문제 풀이 추가 클래스
 * @author bey15
 *
 */
@WebServlet("/solving/addsolving.do")
public class AddSolving extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddSolving.java
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "5";

		req.setAttribute("active", active);
		
		
		
		String rnum = req.getParameter("rnum");
		req.setAttribute("rnum", rnum);
		
		
		
		
		String algorithmNum = req.getParameter("algorithmNum");
		req.setAttribute("algorithmNum", algorithmNum);
		
		
		
		System.out.println(algorithmNum);
		
		//SolvingDAO dao = new SolvingDAO();
		//int result = dao.addSoving();
		
		//req.setAttribute("result", result);
		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/solving/addsolving.jsp");
		dispatcher.forward(req, resp);

	}

}
