package com.wmc.etc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 동영상 강의 링크연결 클래스
 * @author bey15
 *
 */
@WebServlet("/etc/youtuberedirect.do")
public class YoutubeRedirect extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//YoutubeRedirect.java
		String url = req.getParameter("url");
		String seq = req.getParameter("seq");
		
		EtcDAO dao = new EtcDAO();
		dao.addViewCnt(seq);
		
		
		
		
		resp.sendRedirect(url);

	}

}
