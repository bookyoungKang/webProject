package com.wmc.etc;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 동영상 강의 추가하는 클래스
 * @author bey15
 *
 */
@WebServlet("/etc/addyoutube.do")
public class AddYoutube extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddYoutube.java
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "7";

		req.setAttribute("active", active);
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String title = req.getParameter("title");
		String youtubeurl = req.getParameter("youtubeurl");
		String rating = session.getAttribute("rating").toString();
		
		EtcDAO dao = new EtcDAO();
		YoutubeDTO dto = new YoutubeDTO();
		
		dto.setId(rating);
		dto.setTitle(title);
		dto.setYoutubeurl(youtubeurl);
		
		int result = dao.addUrl(dto);
		
		req.setAttribute("result", result);
		req.setAttribute("rating", rating);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/etc/addyoutube.jsp");
		dispatcher.forward(req, resp);

	}

}
