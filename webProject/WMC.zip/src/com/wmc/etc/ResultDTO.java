package com.wmc.etc;

/**
 * 채점을 위한 데이터를 담을 클래스
 * @author bey15
 *
 */
public class ResultDTO {

	private String resultRnum;
	private String rnum;
	private String seq;
	private String id;
	private String languageType;
	private String result;
	private String regdate;
	
	
	
	public String getResultRnum() {
		return resultRnum;
	}
	public void setResultRnum(String resultRnum) {
		this.resultRnum = resultRnum;
	}
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLanguageType() {
		return languageType;
	}
	public void setLanguageType(String languageType) {
		this.languageType = languageType;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
}
