package com.wmc.etc;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 사용자간의 대결을 위한 클래스
 * @author bey15
 *
 */
@WebServlet("/etc/battle.do")
public class Battle extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//Battle.java
		
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "8";
		
		
		//돌아다니는 아이디
		HttpSession session = req.getSession();
		
		String certification = session.getAttribute("certification").toString();  // 세션 아이디
		String id = req.getParameter("id");   // 클릭한 아이디
		
		
		EtcDAO dao = new EtcDAO();

		
		ArrayList<BattleDTO> list = dao.blist(id);
		ArrayList<BattleDTO> clist = dao.clist(certification);
		ArrayList<BattleDTO> sumlist = dao.sumlist(id,certification);
		
		req.setAttribute("id", id); //파라미터 (클릭 당한 애)
		req.setAttribute("certification", certification); //세션
		
		
		req.setAttribute("list", list);
		req.setAttribute("clist", clist);
		req.setAttribute("sumlist", sumlist);

		
		req.setAttribute("active", active);
		
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/etc/battle.jsp");
		dispatcher.forward(req, resp);

	}

}
