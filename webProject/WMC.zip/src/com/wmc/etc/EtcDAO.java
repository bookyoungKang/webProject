package com.wmc.etc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

public class EtcDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	public EtcDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}

	public ArrayList<ResultDTO> list(HashMap<String, String> map) {

		try {

			String where = "";
			if (map.get("isSearch").equals("true")) {

				where = String.format("where %s like '%%%s%%' and", map.get("column"), map.get("word"));
			}

			String sql = String.format(
					"SELECT * FROM (SELECT A.*, ROWNUM AS RNUM2 FROM (SELECT * FROM resultlist %s ORDER BY resultrnum DESC) A) WHERE RNUM2 BETWEEN %s AND %s",
					where, map.get("begin"), map.get("end"));

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			ArrayList<ResultDTO> list = new ArrayList<ResultDTO>();

			while (rs.next()) {

				ResultDTO ldto = new ResultDTO();

				ldto.setResultRnum(rs.getString("resultRnum"));
				ldto.setId(rs.getString("id"));
				ldto.setRnum(rs.getString("rnum"));
				ldto.setResult(rs.getString("result"));
				ldto.setLanguageType(rs.getString("languageType"));
				ldto.setRegdate(rs.getString("regdate"));

				list.add(ldto);
			}

			return list;

		} catch (Exception e) {
			System.out.println("ResultDAO.getTotalCount : " + e.toString());
		}

		return null;
	}

	public int getTotalCount(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select count(*) as cnt from resultlist %s", where);

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("ResultDAO.getTotalCount : " + e.toString());
		}

		return 0;
	}

	public ArrayList<YoutubeDTO> ylist(HashMap<String, String> map) {
	
		try {

			String where = "";
			if (map.get("isSearch").equals("true")) {

				where = String.format("where %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format(
					"SELECT * FROM (SELECT A.*, ROWNUM AS RNUM2 FROM (SELECT * FROM tblyoutube %s ORDER BY seq DESC) A) WHERE RNUM2 BETWEEN %s AND %s",
					where, map.get("begin"), map.get("end"));

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			ArrayList<YoutubeDTO> list = new ArrayList<YoutubeDTO>();

			while (rs.next()) {

				YoutubeDTO ldto = new YoutubeDTO();
				
				ldto.setSeq(rs.getString("seq"));
				ldto.setTitle(rs.getString("title"));
				ldto.setId(rs.getString("id"));
				ldto.setViewcnt(rs.getString("viewcnt"));
				ldto.setRegdate(rs.getString("regdate"));
				ldto.setYoutubeurl(rs.getString("youtubeurl"));
				ldto.setPic(rs.getString("pic"));
				ldto.setRnum(rs.getString("rnum2"));
				ldto.setStatus(rs.getString("status"));
				
				list.add(ldto);
			}

			return list;

		} catch (Exception e) {
			System.out.println("EtcDAO.getTotalCount : " + e.toString());
		}

		return null;
	}

	public int getTotalCnt(HashMap<String, String> map) {   // 동영상 getTotalCount

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select count(*) as cnt from tblyoutube %s", where);

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("EtcDAO.getTotalCnt : " + e.toString());
		}

		return 0;
	}

	public void addViewCnt(String seq) {

		try {

			String sql = "UPDATE tblyoutube SET viewcnt = viewcnt+1 where seq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			//System.out.println(stat.executeUpdate());
			stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("EtcDAO.addViewCnt : " + e.toString());
		}

		
	}

	public ArrayList<RankingDTO> rlist(HashMap<String, String> map) {
		
		try {

			String where = "";
			if(map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'"
						, map.get("column"), map.get("word"));
			}
			
			String sql = String.format("SELECT * FROM (SELECT * FROM FINALRANKEND %s ORDER BY TOTAL DESC)A where rnum2 between %s and %s"
						, where
						, map.get("begin")
						, map.get("end"));
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<RankingDTO> list = new ArrayList<RankingDTO>();
			
			while (rs.next()) {
				
				RankingDTO dto = new RankingDTO();
				
				dto.setRnum2(rs.getString("rnum2"));
				dto.setRnum(rs.getString("rnum"));
				dto.setId(rs.getString("id"));
				dto.setMs(rs.getString("ms"));
				dto.setTotal(rs.getString("total"));
				dto.setCorrect(rs.getString("correct"));
				dto.setSub(rs.getString("sub"));
				dto.setPer(rs.getString("per"));
				
				list.add(dto);
			}
			return list;
		} catch (Exception e) {
			System.out.println("EtcDAO.rlist : " + e.toString());
		}

		
		return null;
	}

	public int getTotalCount1(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select count(*) as cnt from tblyoutube %s", where);

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("EtcDAO.getTotalCount1 : " + e.toString());
		}

		return 0;
	}

	public int addUrl(YoutubeDTO dto) {

		try {
			
			String sql = "insert into tblyoutube(seq,title,id,viewcnt,regdate,youtubeurl,pic,status) " + 
								"values(youtube_seq.nextval, ?,?,default,sysdate,?,default,default)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getTitle());
			stat.setString(2, dto.getId());
			stat.setString(3, dto.getYoutubeurl());
			
			return stat.executeUpdate();
			
			
		}catch (Exception e) {
			System.out.println("EtcDAO.addYoutube : " + e.toString());
		}
		return 0;
	}

	public ArrayList<BattleDTO> blist(String id) {

		try {

			String sql = "select * from (select distinct(questionnum),id from temp where id = ?)";

			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			
			rs = stat.executeQuery();

			ArrayList<BattleDTO> list = new ArrayList<BattleDTO>();
			
			while (rs.next()) {
				
				BattleDTO dto = new BattleDTO();
				
				dto.setId(rs.getString("id"));
				dto.setQuestionnum(rs.getString("questionnum"));
				
			list.add(dto);
			}
			return list;
			
			
		} catch (Exception e) {
			System.out.println("EtcDAO.blist : " + e.toString());
		}

		return null;
	}

	public ArrayList<BattleDTO> clist(String certification) {

		try {

			String sql = "select * from (select distinct(questionnum),id from temp where id = ?)";

			stat = conn.prepareStatement(sql);
			stat.setString(1, certification);
			
			rs = stat.executeQuery();

			ArrayList<BattleDTO> clist = new ArrayList<BattleDTO>();
			
			while (rs.next()) {
				
				BattleDTO dto = new BattleDTO();
				
				dto.setId(rs.getString("id"));
				dto.setQuestionnum(rs.getString("questionnum"));
				
			clist.add(dto);
			}
			return clist;
			
			
		} catch (Exception e) {
			System.out.println("EtcDAO.blist : " + e.toString());
		}
		return null;
	}

	public ArrayList<BattleDTO> sumlist(String id, String certification) {

		try {

			String sql = "select * from (select distinct(questionnum)as a from temp where id = ?) intersect select * from (select distinct(questionnum)as a from temp where id = ?)";

			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			stat.setString(2, certification);
			
			rs = stat.executeQuery();
			
			ArrayList<BattleDTO> sumlist = new ArrayList<BattleDTO>();
			
			while (rs.next()) {
				
				BattleDTO dto = new BattleDTO();
				
				dto.setQuestionnum(rs.getString("a"));
				
				sumlist.add(dto);
			}
			return sumlist;
			
		} catch (Exception e) {
			System.out.println("EtcDAO.sumlist : " + e.toString());
		}

		return null;
	}

	


}




















