package com.wmc.etc;

/**
 * 사용자 랭킹 정보 데이터를 담을 클래스
 * @author bey15
 *
 */
public class RankingDTO {

	private String seq;
	private String rnum;
	private String rnum2;
	private String id;
	private String ms;
	private String total;
	private String correct;
	private String sub;
	private String per;
	
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMs() {
		return ms;
	}
	public void setMs(String ms) {
		this.ms = ms;
	}
	public String getCorrect() {
		return correct;
	}
	public void setCorrect(String correct) {
		this.correct = correct;
	}
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getPer() {
		return per;
	}
	public void setPer(String per) {
		this.per = per;
	}
	public String getRnum2() {
		return rnum2;
	}
	public void setRnum2(String rnum2) {
		this.rnum2 = rnum2;
	}
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	
	
}
