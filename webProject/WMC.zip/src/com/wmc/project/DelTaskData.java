package com.wmc.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 삭제할 업무 객체 생성시 필요한 데이터를 DB에서 가져오는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/deltaskdata.do")
public class DelTaskData extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String taskSeq = req.getParameter("taskSeq");
		ProjectDAO dao = new ProjectDAO();
		int result  =  dao.delTask(taskSeq);

		resp.setContentType("application/json");
		
		PrintWriter writer = resp.getWriter();
		
		writer.print("{");
		
		writer.printf("\"result\" : \"%d\"", result);
		
		writer.print("}");
		writer.close();
	}
}
