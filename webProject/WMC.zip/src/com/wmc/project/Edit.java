package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 수정할 프로젝트 객체를 생성하는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/edit.do")
public class Edit extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String seq = req.getParameter("seq");
		
		HttpSession session = req.getSession();
		String id = session.getAttribute("certification").toString();
		
		ProjectDAO dao = new ProjectDAO();
		ArrayList<VwProModDTO> proModList  = dao.getProMod(seq);
		ArrayList<VwMembers> members = dao.getMembers(seq);
		ArrayList<VwMyTasksDTO> tasks = dao.getTasks(seq);
		
		for (VwProModDTO dto: proModList) {
			String eDate = dto.geteDate().substring(0, 10);
			String sDate = dto.getsDate().substring(0, 10);
			
			dto.seteDate(eDate);
			dto.setsDate(sDate);
			
		}
		
		req.setAttribute("seq", seq);
		req.setAttribute("proModList", proModList);
		req.setAttribute("members", members);
		req.setAttribute("tasks", tasks);
		req.setAttribute("id", id);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/edit.jsp");
		dispatcher.forward(req, resp);
	}
}
