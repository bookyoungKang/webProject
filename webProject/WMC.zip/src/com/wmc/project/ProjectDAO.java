package com.wmc.project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.wmc.DBUtil;
import com.wmc.member.MemberDTO;

public class ProjectDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public ProjectDAO() {
		DBUtil util = new DBUtil();
		conn= util.connect();
	}

	public ArrayList<MemberDTO> getSearchResult(String keyword) {
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();
		try {
			
			String sql="select name, id from tblMember where id =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, keyword);
			
			rs = stat.executeQuery();
			while(rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setName(rs.getString("name"));
				dto.setId(rs.getString("id"));
				
				list.add(dto);
			}
			return list;
					
		} catch (Exception e) {
			System.out.println("ProjectDAO.getSearchResult: " + e.toString());
		}
		return null;
	}

	public int addProject(ProjectDTO projectDto) {

		try {
			
			String sql="insert into tblProject (seq, name, note, sDate, eDate, exist) "
					+ "values(project_seq.nextval, ?, ?, ?, ?, default)";
			stat = conn.prepareStatement(sql);
			stat.setString(1, projectDto.getName());
			stat.setString(2, projectDto.getNote());
			stat.setString(3, projectDto.getsDate());
			stat.setString(4, projectDto.geteDate());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.addProject: " + e.toString());
		}
		
		return 0;
	}

	public int addMemeber(String id, int maxProject) {
		try {
			
			String sql="insert into tblProjectMember (id, proSeq, lv, exist) values (?, ?, default, default)";
			stat=conn.prepareStatement(sql);
			stat.setString(1, id);
			stat.setInt(2, maxProject);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.addMemeber: " + e.toString());
		}
		return 0;
	}

	public int addLeader(String leader, int maxProject) {
		try {
			
			String sql="insert into tblProjectMember (id, proSeq, lv, exist) values (?, ?, 2, default)";
			stat=conn.prepareStatement(sql);
			stat.setString(1, leader);
			stat.setInt(2, maxProject);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.addLeader: " + e.toString());
		}
		return 0;
	}
	
	public int getMaxProject() {
		try {
			
			String sql="select max(seq) as max from tblProject";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			if (rs.next()) {
				return rs.getInt("max");
			}
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getMaxProject: " + e.toString());
		}
		return 0;
	}

	public int addModule(ModuleDTO moduleDto, int maxProject) {
		try {
			
			String sql="insert into tblModule (seq, proSeq, moduleTaker, name, progress, exist) "
					+ "values (module_seq.nextval, ?, ?, ?, default, default)";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, maxProject);
			stat.setString(2, moduleDto.getModuleTaker());
			stat.setString(3, moduleDto.getName());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.addModule: " + e.toString());
		}
		return 0;
	}

	public int addTask(TaskDTO taskDto, int maxModule) {
		try {
			
			String sql="insert into tblTask (seq, modSeq, taskTaker, priority, name, status, exist) "
					+ "values (task_seq.nextval, ?, ?, ?, ?, ?, default)";
			stat = conn.prepareStatement(sql);
			stat.setInt(1, maxModule);
			stat.setString(2, taskDto.getTaskTaker());
			stat.setString(3, taskDto.getPriority());
			stat.setString(4, taskDto.getName());
			stat.setString(5, taskDto.getStatus());
//			if (taskDto.getStatus() == null) stat.setString(5, "0");
//			else if (taskDto.getStatus() != null) stat.setString(5, "1"); 
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.addTask: " + e.toString());
		}
		return 0;
	}

	public ArrayList<VwProMemDTO> getProjectList(String id) {
		try {
			
			String sql="select * from vwpromem where id =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			rs = stat.executeQuery();
			
			ArrayList<VwProMemDTO> list = new ArrayList<VwProMemDTO>();
			while(rs.next()) {
				VwProMemDTO dto = new VwProMemDTO();
				
				dto.setSeq(rs.getString("SEQ"));
				dto.setId(rs.getString("ID"));
				dto.setName(rs.getString("NAME"));
				dto.setNote(rs.getString("NOTE"));
				dto.setSdate(rs.getString("SDATE"));
				dto.setEdate(rs.getString("EDATE"));
				dto.setProgress(rs.getString("PROGRESS"));
				dto.setIsDone(rs.getString("ISDONE"));
				dto.setLv(rs.getString("lv"));
				
				list.add(dto);
			}
			return list;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getProjectList: " + e.toString());
		}
		return null;
	}

	public int getMaxModule() {
		try {
			
			String sql="select max(seq) as max from tblModule";
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			if (rs.next()) {
				return rs.getInt("max");
			}
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getMaxModule: " + e.toString());
		}
		return 0;
	}

	public ArrayList<VwProModDTO> getProMod(String seq) {
		
		ArrayList<VwProModDTO> proModList =  new ArrayList<VwProModDTO>();
		
		try {
			
			String sql="select * from vwProMod where proSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			
			while(rs.next()) {
				VwProModDTO promodDto = new VwProModDTO();
				
				promodDto.setProjectName(rs.getString("PROJECTNAME"));
				promodDto.setProjectNote(rs.getString("PROJECTNOTE"));
				promodDto.setProProgress(rs.getString("PROPROGRESS"));
				promodDto.setsDate(rs.getString("SDATE"));
				promodDto.seteDate(rs.getString("EDATE"));
				promodDto.setId(rs.getString("MODULETAKER"));
				promodDto.setName(rs.getString("NAME"));
				promodDto.setModSeq(rs.getString("MODSEQ"));
				promodDto.setModName(rs.getString("MODNAME"));
				promodDto.setModProgress(rs.getString("MODPROGRESS"));
				promodDto.setTaskDone(rs.getInt("taskDone"));
				promodDto.setTotalTask(rs.getInt("totalTask"));
				
				proModList.add(promodDto);
			}
			
			return proModList;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getProMod: " + e.toString());
		}
		return null;
	}

	public ArrayList<VwMyTasksDTO> getMyTasks(String id, String seq) {

		try {
			
			String sql="select * from vwMyTasks where taskTaker =? and proSeq = ?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			stat.setString(2, seq);
			
			rs = stat.executeQuery();
			
			ArrayList<VwMyTasksDTO> tasks = new ArrayList<VwMyTasksDTO>();
			
			while(rs.next()) {
				
				VwMyTasksDTO dto = new VwMyTasksDTO();
				
				dto.setTaskSeq(rs.getString("TASKSEQ"));
				dto.setTaskName(rs.getString("TASKNAME"));
				dto.setTaskPriority(rs.getString("TASKPRIORITY"));
				dto.setTaskStatus(rs.getString("TASKSTATUS"));
				dto.setTaskTaker(rs.getString("TASKTAKER"));
				dto.setModSeq(rs.getString("MODSEQ"));
				dto.setModName(rs.getString("MODNAME"));
				dto.setProSeq(rs.getString("PROSEQ"));
				
				tasks.add(dto);
			}
			
			return tasks;
		} catch (Exception e) {
			System.out.println("ProjectDAO.getMyTasks: " + e.toString());
		}
		return null;
	}

	public ArrayList<VwMembers> getMembers(String seq) {

		try {
			
			String sql="select * from vwmembers where proseq=? and exist = 1";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			 ArrayList<VwMembers> members = new  ArrayList<VwMembers>();
			
			while(rs.next()) {
				VwMembers dto = new VwMembers();
				dto.setId(rs.getString("id"));
				dto.setName(rs.getString("name"));
				dto.setLv(rs.getString("lv"));
				
				members.add(dto);
			}
			return members;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.geMembers: " + e.toString());
		}
		return null;
	}

	public ArrayList<VwMyTasksDTO> getTasks(String seq) {
		try {
			
			String sql="select * from vwMyTasks where proseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
					
			ArrayList<VwMyTasksDTO> tasks = new ArrayList<VwMyTasksDTO>();
			while(rs.next()) {
				VwMyTasksDTO dto  = new VwMyTasksDTO();
				dto.setTaskName(rs.getString("TASKNAME"));
				dto.setTaskPriority(rs.getString("TASKPRIORITY"));
				dto.setTaskStatus(rs.getString("TASKSTATUS"));
				dto.setTaskTaker(rs.getString("TASKTAKER"));
				dto.setTaskSeq(rs.getString("TASKSEQ"));
				dto.setModSeq(rs.getString("MODSEQ"));
				dto.setModName(rs.getString("MODNAME"));
				
				tasks.add(dto);
			}
			
			return tasks;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getTasks: " + e.toString());
		}
		return null;
	}

	public int del(String seq, String id) {
		
		try {
			
			String sql="UPDATE tblProjectMember SET exist= 0 where proseq=? and id=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			stat.setString(2, id);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.del: " + e.toString());
		}
		return 0;
	}

	public boolean exist(String id, String seq) {
		
		try {
			
			String sql="select exist from tblProjectMember where id =? and proseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			stat.setString(2, seq);
			
			rs = stat.executeQuery();
			int exist = 1;
			while(rs.next()) {
				exist += rs.getInt("exist");
			}
			
			if(exist > 0) return true;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.exist: " + e.toString());
		}
		return false;
	}

	public int editProject(ProjectDTO projectDto, String seq) {
		
		try {
			
			String sql="update tblProject set name=?, note=?, sDate=?, eDate=? where seq= ?";
			stat= conn.prepareStatement(sql);
			stat.setString(1, projectDto.getName());
			stat.setString(2, projectDto.getNote());
			stat.setString(3, projectDto.getsDate());
			stat.setString(4, projectDto.geteDate());
			stat.setString(5, seq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.editProject: " + e.toString());
		}
		return 0;
	}

	public int removeLeader(String seq) {
		try {
			
			String sql="update tblProjectMember set lv = 1 where proseq=? and exist = 1";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.removeLeader: " + e.toString());
		}
		return 0;
	}

	public int removeMembers(String seq) {
		
		try {
			
			String sql="update tblProjectMember set exist = 0 where proseq=? and exist = 1";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.removeMembers: " + e.toString());
		}
		return 0;
	}

	public int removeModules(String seq) {
		
		try {
			int result = 1;
			
			String sql="update tblModule set exist = 0 where proseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			result *= stat.executeUpdate();
			
			String sql2="update tblTask set exist = 0 where modSeq in (select seq from tblModule where proseq =?)";
			stat = conn.prepareStatement(sql2);
			stat.setString(1, seq);
			result *= stat.executeUpdate();
			
			return result;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.removeModules: " + e.toString());
		}
		return 0;
	}

	public int removeTasks(String seq) {
		
		try {
			
			String sql="update tblTask set exist = 0 where modseq in (select seq from tblModule where proseq = ?)";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.removeTasks: " + e.toString());
		}
		return 0;
	}

	public VwMyTasksDTO getTask(String seq) {
		
		try {
			
			String sql="select * from VwMyTasks where taskseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			
			if (rs.next()) {
				VwMyTasksDTO dto = new VwMyTasksDTO();
				dto.setTaskName(rs.getString("TASKNAME"));
				dto.setTaskPriority(rs.getString("TASKPRIORITY"));
				dto.setTaskStatus(rs.getString("TASKSTATUS"));
				dto.setModSeq(rs.getString("MODSEQ"));
				dto.setModName(rs.getString("MODNAME"));
				dto.setTaskTaker(rs.getString("TASKTAKER"));
				return dto;
			}
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getTask: " + e.toString());
		}
		return null;
	}

	public int editTask(String seq, TaskDTO dto) {
		
		try {
			
			String sql="update tblTask set priority =?, status =?, name =? where seq =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getPriority());
			stat.setString(2, dto.getStatus());
			stat.setString(3, dto.getName());
			stat.setString(4, seq);
			
			return stat.executeUpdate();
		} catch (Exception e) {
			System.out.println("ProjectDAO.editTask: " + e.toString());
		}
		return 0;
	}

	public int delTask(String taskSeq) {

		try {
			
			String sql="update tblTask set exist = 0 where seq =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, taskSeq);
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.delTask: " + e.toString());
		}
		return 0;
	}

	public ArrayList<VwModProgressDTO> getVwModProgress(String seq) {

		try {
			
			String sql="select * from vwModProgress where proseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			ArrayList<VwModProgressDTO> list = new ArrayList<VwModProgressDTO>();
			
			while(rs.next()) {
			
				VwModProgressDTO dto = new VwModProgressDTO();
				dto.setProSeq(rs.getString("PROSEQ"));
				dto.setId(rs.getString("moduletaker"));
				dto.setName(rs.getString("NAME"));
				dto.setTaskDone(rs.getInt("TASKDONE"));
				dto.setTotalTask(rs.getInt("TOTALTASK"));
				
				list.add(dto);
			}
			return list;
		} catch (Exception e) {
			System.out.println("ProjectDAO.getVwModProgress: " + e.toString());
		}
		return null;
	}

	public ArrayList<VwCountTaskDTO> getCountTask(String seq) {

		try {
			
			String sql="select * from VwCountTask where proseq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			ArrayList<VwCountTaskDTO> list = new ArrayList<VwCountTaskDTO>();
			while(rs.next()) {
				VwCountTaskDTO dto = new VwCountTaskDTO();
				dto.setProSeq(rs.getString("PROSEQ"));
				dto.setId(rs.getString("ID"));
				dto.setName(rs.getString("NAME"));
				dto.setTaskDone(rs.getInt("TASKDONE"));
				dto.setTotalTask(rs.getInt("TOTALTASK"));
				
				list.add(dto);
			}
			return list;
		} catch (Exception e) {
			System.out.println("ProjectDAO.getCountTask: " + e.toString());
		}
		return null;
	}

	public ArrayList<VwCountTask2DTO> getCountTask2(String id) {
		
		try {
			
			String sql="select  proseq, taskDone, totalTask from vwCountTask2 where proseq in (select proseq from tblProjectMember where id = ? and exist =1)";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			rs = stat.executeQuery();
			
			ArrayList<VwCountTask2DTO> list = new ArrayList<VwCountTask2DTO>();
			while(rs.next()) {
				VwCountTask2DTO dto = new VwCountTask2DTO();
				dto.setProSeq(rs.getString("PROSEQ"));
				dto.setTaskDone(rs.getInt("TASKDONE"));
				dto.setTotalTask(rs.getInt("TOTALTASK"));
				
				list.add(dto);
			}
			return list;
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getCountTask2: " + e.toString());
		}
		return null;
	}

	public ProjectDTO getProject(String seq) {
		
		try {
			
			String sql="select * from tblProject where seq=?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				ProjectDTO dto = new ProjectDTO();
				dto.setName(rs.getString("name"));
				dto.setNote(rs.getString("note"));
				return dto;
			}
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getProject: " + e.toString());
		}
		return null;
	}

	public String getLv(String id, String seq) {
		try {
			
			String sql="select lv from tblProjectMember where id = ? and proseq = ? and exist =1";
			stat = conn.prepareStatement(sql);
			stat.setString(1, id);
			stat.setString(2, seq);
			
			rs = stat.executeQuery();
			if(rs.next()) return rs.getString("lv");
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getLv: " + e.toString());
		}
		return null;
	}

	public VwCountTask2DTO getProProgress(String seq) {
		try {
			
			String sql="select proseq, taskDone, totalTask from vwCountTask2 where proseq =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			if(rs.next()) {
				VwCountTask2DTO dto = new VwCountTask2DTO();
				
				System.out.println("-----------------");
				System.out.println("rs.getTaskDone : " + rs.getInt("taskDone"));
				System.out.println("rs.totalTask : " + rs.getInt("totalTask"));
				System.out.println("-----------------");
				
				dto.setTaskDone(rs.getInt("taskDone"));
				dto.setTotalTask(rs.getInt("totalTask"));
				
				return dto;
			}
			
		} catch (Exception e) {
			System.out.println("ProjectDAO.getProProgress: " + e.toString());
		}
		return null;
	}

	



	
	
	
}
