package com.wmc.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 업무 객체 생성시 필요한 데이터를 DB에서 가져오는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/addtaskdata.do")
public class AddTaskData extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		String proSeq = req.getParameter("proSeq");
		String id = req.getParameter("id");
		String modName = req.getParameter("modName");
		
		ProjectDAO dao = new ProjectDAO();
		ModuleDTO dto = new ModuleDTO();
		dto.setProSeq(proSeq);
		dto.setModuleTaker(id);
		dto.setName(modName);
		
		int result = dao.addModule(dto, Integer.parseInt(proSeq));
		
		int maxModule = dao.getMaxModule();
		
		resp.setContentType("application/json");
		PrintWriter writer = resp.getWriter();
		
		writer.print("{");
			writer.printf("\"result\" : \"%d\",", result);
			writer.printf("\"maxModule\" : \"%d\"", maxModule);
		writer.print("}");
		writer.close();
	}
}

















