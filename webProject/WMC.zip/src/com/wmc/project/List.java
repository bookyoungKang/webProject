package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 로그인한 회원이 속한 프로젝트를 DB에서 가져와 jsp에 전달하는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/list.do")
public class List extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession(true);
		String id = session.getAttribute("certification").toString();
		
		req.setCharacterEncoding("utf-8");
		
		ProjectDAO dao = new ProjectDAO();
		ArrayList<VwProMemDTO> projectList = dao.getProjectList(id);
		
		// 프로젝트 진행률 계산해서 보여주기
		
		ArrayList<VwCountTask2DTO> proProgresses =  dao.getCountTask2(id);
		for(VwCountTask2DTO cDto : proProgresses) {
			String cSeq = cDto.getProSeq();
			
			// 계산
			
			double rate = 0;
			
			int taskDone = cDto.getTaskDone();
			int totalTask = cDto.getTotalTask();
			
			if (totalTask != 0) {
				rate = ((double)taskDone / totalTask) * 100;
			}
			
			for (VwProMemDTO vDto : projectList) {
				String seq = vDto.getSeq();
				if (cSeq.equals(seq)) vDto.setProgress(rate + "");
			}
			
		}
		
		req.setAttribute("projectList", projectList);
		req.setAttribute("id", id);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/list.jsp");
		dispatcher.forward(req, resp);
	}
}
