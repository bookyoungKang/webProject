package com.wmc.project;

/**
 * 프로젝트와 회원의 관계 객체 클래스
 * @author bey15
 *
 */
public class ProjectMemberDTO {

	private String id;
	private String proSeq;
	private String exist;
	private String lv;
	
	public String getLv() {
		return lv;
	}
	public void setLv(String lv) {
		this.lv = lv;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public String getExist() {
		return exist;
	}
	public void setExist(String exist) {
		this.exist = exist;
	}
	
	
}
