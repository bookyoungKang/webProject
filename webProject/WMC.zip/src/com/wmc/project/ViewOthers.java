package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 로그인한 회원 이외 회원의 업무 객체를 DB에서 가져와 jsp에 전달하는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/viewothers.do")
public class ViewOthers extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// 1. view할 seq랑 id
		
		req.setCharacterEncoding("utf-8");
		
		// 지금 보러가는 회원
		String id = req.getParameter("id");
		
		// 지금 보러가는 프로젝트 == 이따 돌아올 프로젝트
		String seq = req.getParameter("proSeq");

		// 프로젝트 이름
		String proName = req.getParameter("proName");
		
		// 회원 이름
		String name = req.getParameter("name");

		ProjectDAO dao = new ProjectDAO();
		
		// 2. myTasks
		ArrayList<VwMyTasksDTO> myTasks = dao.getMyTasks(id, seq);
		
		req.setAttribute("id", id);
		req.setAttribute("seq", seq); // 프로젝트 번호
		req.setAttribute("myTasks", myTasks);
		req.setAttribute("name", name);
		req.setAttribute("proName", proName);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/viewothers.jsp");
		dispatcher.forward(req, resp);
	}
}












