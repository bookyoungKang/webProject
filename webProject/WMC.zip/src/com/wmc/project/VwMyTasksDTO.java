package com.wmc.project;

public class VwMyTasksDTO {
	
	private String taskSeq;
	private String taskName;
	private String taskPriority;
	private String taskStatus;
	private String taskTaker;
	private String modSeq;
	private String proSeq;
	private String modName;
	
	public String getTaskSeq() {
		return taskSeq;
	}
	public void setTaskSeq(String taskSeq) {
		this.taskSeq = taskSeq;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getTaskPriority() {
		return taskPriority;
	}
	public void setTaskPriority(String taskPriority) {
		this.taskPriority = taskPriority;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getTaskTaker() {
		return taskTaker;
	}
	public void setTaskTaker(String taskTaker) {
		this.taskTaker = taskTaker;
	}
	public String getModSeq() {
		return modSeq;
	}
	public void setModSeq(String modSeq) {
		this.modSeq = modSeq;
	}
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public String getModName() {
		return modName;
	}
	public void setModName(String modName) {
		this.modName = modName;
	}
	
	

}
