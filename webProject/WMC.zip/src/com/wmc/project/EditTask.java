package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 수정할 업무 객체를 생성하는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/edittask.do")
public class EditTask extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		req.setCharacterEncoding("utf-8");

		String seq = req.getParameter("seq");
		String proSeq = req.getParameter("proSeq");
		
		ProjectDAO dao = new ProjectDAO();
		VwMyTasksDTO task = dao.getTask(seq);
		ProjectDTO proDto = dao.getProject(proSeq);
		
		req.setAttribute("task", task);
		req.setAttribute("seq", seq);
		req.setAttribute("proSeq", proSeq);
		req.setAttribute("proDto", proDto);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/edittask.jsp");
		dispatcher.forward(req, resp);
	}
}
