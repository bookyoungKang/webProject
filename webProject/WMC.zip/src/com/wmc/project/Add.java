package com.wmc.project;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 프로젝트 객체를 생성하는 클래스
 * @author bey15
 *
 */
@WebServlet("/project/add.do")
public class Add extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/add.jsp");
		dispatcher.forward(req, resp);
	}
}
