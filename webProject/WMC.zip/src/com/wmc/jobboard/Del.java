package com.wmc.jobboard;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 게시물 삭제 클래스
 * @author bey15
 *
 */
@WebServlet("/jobboard/del.do")
public class Del extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String seq = req.getParameter("seq");

		JobBoardDTO dto = new JobBoardDTO();

		dto.setSeq(seq);

		JobBoardDAO dao = new JobBoardDAO();

		int result = dao.del(dto);

		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");

		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

	}

}