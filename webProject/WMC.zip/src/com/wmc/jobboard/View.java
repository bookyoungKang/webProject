package com.wmc.jobboard;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 게시물 상세보기 클래스
 * @author bey15
 *
 */
@WebServlet("/jobboard/view.do")
public class View extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		String seq = req.getParameter("seq");
		
		JobBoardDAO dao = new JobBoardDAO();
		
		JobBoardDTO dto = dao.view(seq);
		
		//댓글
		ArrayList<CommentDTO> clist = dao.listComment(seq);
		
		int cntComment = dao.countComment(seq);
		
		req.setAttribute("dto", dto);
		req.setAttribute("clist", clist);
		req.setAttribute("cntComment", cntComment);
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/jobboard/view.jsp");
		dispatcher.forward(req, resp);
	}

}
