package com.wmc.jobboard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.member.MemberDTO;

/**
 * 게시물 추가 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/jobboard/addok.do")
public class AddOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String dlyear = req.getParameter("dlyear");
		String dlmonth = req.getParameter("dlmonth");
		String dlday = req.getParameter("dlday");
		String contentGrade = req.getParameter("contentGrade");
		String lat = req.getParameter("lat");
		String lng = req.getParameter("lng");
		
		if (contentGrade == null || contentGrade.equals("")) {
			contentGrade = "1";
		}
		
		JobBoardDTO dto = new JobBoardDTO();
		
		dto.setTitle(title);
		dto.setContent(content);
		String dldate = dlyear + "-" + dlmonth + "-" + dlday;
		dto.setDldate(dldate);
		dto.setWriter((String) session.getAttribute("certification"));
		dto.setGrade(contentGrade);
		dto.setLat(lat);
		dto.setLng(lng);
		
		JobBoardDAO dao = new JobBoardDAO();
		
		int result = dao.add(dto);
		
		req.setAttribute("result", result);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/jobboard/addok.jsp");
		dispatcher.forward(req, resp);
	}

}