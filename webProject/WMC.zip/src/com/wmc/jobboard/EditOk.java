package com.wmc.jobboard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 게시물 수정 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/jobboard/editok.do")
public class EditOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();

		String seq = req.getParameter("seq");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String dlyear = req.getParameter("dlyear");
		String dlmonth = req.getParameter("dlmonth");
		String dlday = req.getParameter("dlday");
		String lat = req.getParameter("lat");
		String lng = req.getParameter("lng");

		JobBoardDTO dto = new JobBoardDTO();

		dto.setTitle(title);
		dto.setContent(content);
		String dldate = dlyear + "-" + dlmonth + "-" + dlday;
		dto.setDldate(dldate);
		dto.setWriter((String) session.getAttribute("certification"));
		dto.setSeq(seq);
		dto.setLat(lat);
		dto.setLng(lng);
		
		JobBoardDAO dao = new JobBoardDAO();

		int result = dao.edit(dto);

		req.setAttribute("result", result);
		req.setAttribute("seq", seq);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/jobboard/editok.jsp");
		dispatcher.forward(req, resp);
	}

}