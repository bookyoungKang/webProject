package com.wmc.jobboard;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 댓글 추가 클래스
 * @author bey15
 *
 */
@WebServlet("/jobboard/addcomment.do")
public class AddComment extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		
		HttpSession session = req.getSession();
		
		String content = req.getParameter("content");
		String pseq = req.getParameter("pseq");
		
		CommentDTO cdto = new CommentDTO();
		
		cdto.setContent(content);
		cdto.setPseq(pseq);
		System.out.println(session.getAttribute("certification").toString());
		cdto.setWriter(session.getAttribute("certification").toString());
		
		JobBoardDAO dao = new JobBoardDAO();
		
		int result = dao.addComment(cdto);
		
		req.setAttribute("result", result);
		req.setAttribute("pseq", pseq);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/jobboard/addcomment.jsp");
		dispatcher.forward(req, resp);
	}

}