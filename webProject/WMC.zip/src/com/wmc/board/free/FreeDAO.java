package com.wmc.board.free;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

/**
 * 자유게시판 정보 DB연동 클래스
 * @author bey15
 *
 */
public class FreeDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	/**
	 * DB연동을 위한 기초 작업 메소드(생성자)
	 */
	public FreeDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}
	/**
	 * DB연동을 위한 자원을 닫는 메소드
	 */
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	

	//--------------------------------------------------------------------
	/**
	 * 자유게시판 전체 게시물 개수 가져오는 메소드
	 * @param map 검색종류, 검색어
	 * @return 자유게시판 전체 게시물 개수
	 */
	public int getTotalCount(HashMap<String, String> map) {
		
		try {
			//검색 쿼리
			String where = "";
			
			if(map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'" , map.get("column")
															   , map.get("word"));
			
			}//if
			
			//전체 카운트 쿼리
			String sql = String.format("select count(*) as allcnt from vwfreeb %s", where);
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getInt("allcnt");
			}
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.getTotalCount : " + e.toString());
			
		}
				
		
		return 0;
	}

	//--------------------------------------------------------------------
	/**
	 * 자유게시판 게시물 목록 가져오는 메소드
	 * @param map 검색종류, 검색어, 리스트 가져올 번호들
	 * @return 자유게시판 게시물
	 */
	public ArrayList<FreeDTO> list(HashMap<String, String> map) {
		
		
		try {
			
			
			//검색 쿼리
			String where = "";
			
			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'"
														, map.get("column")					                                                                                                                                                                         
														, map.get("word"));
			}
						
			//String tag = "";
			
			//공지사항 맨위로 쿼리
			String sql = String.format("select 0, a.* from vwfreeb a where notice = 1 union select * from" + 
					"(select rownum as rnum, a.* from" + 
					"(select * from vwfreeb where notice = 0 %s order by freeseq desc) a)" + 
					"where rnum between %s and %s" 		, where
											
					, map.get("begin")
														, map.get("end")
														);
			
			stat = conn.prepareStatement(sql);
			
			rs = stat.executeQuery();
			
			ArrayList<FreeDTO> list = new ArrayList<FreeDTO>();
			
									
			//불러오기
			while (rs.next()) {
				
				FreeDTO dto = new FreeDTO();
				
				dto.setFreeSeq(rs.getString("freeseq")); //글번호
				dto.setSubject(rs.getString("subject")); //제목
				dto.setId(rs.getString("id")); //id
				dto.setContent(rs.getString("content")); //내용
				dto.setRegdate(rs.getString("regdate")); //작성시간
				dto.setCnt(rs.getInt("cnt")); //조회수
				dto.setNotice(rs.getString("notice")); //공지사항
				
				dto.setGap(rs.getInt("gap")); //최신글
				dto.setName(rs.getString("name")); //이름
				dto.setCommentcount(rs.getInt("commentcount")); //댓글수
				
				
				list.add(dto);
			}
			
			return list;			
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.list : " + e.toString());
			
		}
		
		
		
		return null;
	}
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 자유게시판 게시물 추가 메소드
	 * @param dto 게시판 추가에 필요한 정보들
	 * @return 성공 1 실패 0
	 */
	public int add(FreeDTO dto) {
		try {
			
			
			String sql="INSERT INTO tblFreeBoard (freeSeq, id, subject, content, regdate, cnt, notice) values (freeboard_seq.nextval, ?, ?, ?, default, default, ?)";
			
			stat = conn.prepareStatement(sql);
			
			
			stat.setString(1, dto.getId());
			stat.setString(2, dto.getSubject());
			stat.setString(3, dto.getContent());
			stat.setString(4, dto.getNotice());
						
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.add : " + e.toString());
			
		}
		
		return 0;
	}
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 자유게시판 조회수 증가 시키는 메소드
	 * @param freeseq 자유게시판 시퀀스 번호
	 */
	public void addCnt(String freeseq) {
		try {
			
			String sql="UPDATE tblFreeBoard set cnt = cnt + 1 where freeseq = ?";
			stat = conn.prepareStatement(sql);
		
			stat.setString(1, freeseq);
			
			stat.executeUpdate();
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.addCnt : " + e.toString());
			
		}
		
		
	}
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 수정할 자유게시판 목록 얻어오기위한 메소드
	 * @param freeSeq 자유게시판 시퀀스 번호
	 * @return 자유게시판 데이터
	 */
	public FreeDTO get(String freeSeq) {
		
		
		try {
			
			String sql="select b.*, (select name from tblMember where id = b.id)" + 
					"as name from tblFreeboard b where freeseq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, freeSeq);
			
			rs = stat.executeQuery();
			
			FreeDTO dto = new FreeDTO();
			
			if (rs.next()) {
				
				dto.setFreeSeq(rs.getString("freeseq")); //글번호
				dto.setSubject(rs.getString("subject")); //제목
				dto.setId(rs.getString("id")); //id
				dto.setContent(rs.getString("content")); //내용
				dto.setRegdate(rs.getString("regdate")); //작성시간
				dto.setCnt(rs.getInt("cnt")); //조회수
				dto.setName(rs.getString("name"));
				
				//dto.setGap(rs.getInt("gap"));
												
				
				
				
				return dto;
				
			}
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.get : " + e.toString());
			
		}
		
		return null;
	}
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 자유게시판 게시물 삭제하는 메소드
	 * @param freeSeq 자유게시판 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int del(String freeSeq) {
		try {			
			
			String sql1 = "DELETE FROM tblFreeComment where pfreeSeq = ?";
			String sql2 = "DELETE FROM tblFreeBoard where freeSeq = ?";
			
			stat = conn.prepareStatement(sql1);
			stat.setString(1, freeSeq);
			
			stat.executeUpdate();
			
			stat = conn.prepareStatement(sql2);
			stat.setString(1, freeSeq);		
			
			
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("FreeDAO.del : " + e.toString());			
		}		
		return 0;
	}
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 자유게시판 게시물 수정하는 메소드
	 * @param dto 수정할 제목, 내용, 시퀀스번호
	 * @return 성공 1 실패 0
	 */
	public int edit(FreeDTO dto) {
		try {
			
			String sql="UPDATE tblFreeBoard set subject = ?, content = ? where freeSeq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getSubject());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getFreeSeq());
			
			return stat.executeUpdate();
						
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.edit : " + e.toString());
			
		}
		return 0;
	}
	//-----------------------------------------------------------------------------------------------------
/**
 * 자유게시판 댓글 추가하는 메소드
 * @param cdto 추가할 댓글내용, 자유게시판게시물 시퀀스 번호, 작성자아이디
 * @return 성공 1 실패 0
 */
	public int addComment(FreeCommentDTO cdto) {
		try {
			
			String sql="INSERT INTO tblFreeComment (fcseq, content, regdate, pfreeSeq, id) values (freecomment_seq.nextval, ? , default, ?, ?)";
		
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getPfreeSeq());
			stat.setString(3, cdto.getId());
			
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.addComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	//-----------------------------------------------------------------------------------------------------
	/**
	 * 자유게시판 게시물 댓글 목록 불러오는 메소드
	 * @param freeseq 자유게시판 게시물 시퀀스 번호
	 * @return 댓글목록
	 */
	public ArrayList<FreeCommentDTO> listComment(String freeseq) {
		
		try {
			
			String sql="select c.*, (select name from tblMember where id = c.id) as name from tblfreecomment c where pfreeSeq = ? order by fcseq desc";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, freeseq);
			
			ArrayList<FreeCommentDTO> clist = new ArrayList<FreeCommentDTO>();
			rs = stat.executeQuery();
			
			while (rs.next()) {
				
				FreeCommentDTO cdto = new FreeCommentDTO();
				
				cdto.setFcSeq(rs.getString("fcseq"));
				cdto.setContent(rs.getString("content"));
				cdto.setName(rs.getString("name"));
				cdto.setId(rs.getString("id"));
				cdto.setPfreeSeq(rs.getString("pfreeseq"));
				
				clist.add(cdto);
				
			}
			
			return clist;
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.listComment : " + e.toString());
			
		}
		return null;
	}
	
	/**
	 * 자유게시판 댓글 수정하는 메소드
	 * @param cdto 수정할 내용, 댓글시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int editComment(FreeCommentDTO cdto) {
		
		try {
			
			String sql="UPDATE tblFreeComment set content = ? where fcSeq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getFcseq());
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.editComment : " + e.toString());
			
		}
		
		
		
		
		
		return 0;
	}
	
	/**
	 * 자유게시판 댓글 삭제하는 메소드
	 * @param fcseq 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delComment(String fcseq) {
		
		try {
			
			String sql="DELETE FROM tblFreeComment WHERE fcseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, fcseq);
			
			return stat.executeUpdate();		
			
			
		} catch (Exception e) {
			
			System.out.println("FreeDAO.delComment : " + e.toString());
			
		}
		
		return 0;
	}
}//class
