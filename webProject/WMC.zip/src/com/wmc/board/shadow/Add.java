package com.wmc.board.shadow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 익명게시판 게시물 추가하는 클래스
 * @author bey15
 *
 */
@WebServlet("/board/shadow/add.do")
public class Add extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//add.java
		
		//인증 사용자
		//AuthCheck auth = new AuthCheck(req.getSession(), resp);
		//auth.allow();
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/shadow/add.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
