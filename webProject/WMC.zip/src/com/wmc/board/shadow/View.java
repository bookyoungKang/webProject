package com.wmc.board.shadow;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 익명 게시판 상세보기를 위한 클래스
 * @author bey15
 *
 */
@WebServlet("/board/shadow/view.do")
public class View extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		String isSearch = req.getParameter("isSearch");
		String column = req.getParameter("column");
		String word = req.getParameter("word");
		
		if (isSearch == null || isSearch == "") {
			isSearch = "false";
		}
		
		//1. 데이터 가져오기
		//2. DB 작업 > DAO 위임(select where)
		//3. 결과 반환 + JSP 호출
		
		
		//1. 글번호
		String shadowseq = req.getParameter("shadowseq");
		
		//2. DB
		ShadowDAO dao = new ShadowDAO();
		
		
		//조회수 증가 F5 금지
		HttpSession session = req.getSession();		
		if (session.getAttribute("isRead") == null 
				|| session.getAttribute("isRead").toString().equals("n")) {
			dao.addCnt(shadowseq);
			session.setAttribute("isRead", "y"); //F5 금지
		}
		
		ShadowDTO dto = dao.get(shadowseq);
		
		
		//개행문자 -> <br>		
		String content = dto.getContent();
		content = content.replace("\r\n", "<br>");		
		dto.setContent(content);
		
		
		
		//내용에서 검색중이면 검색어 강조
		if (isSearch.equals("true") && column.equals("content")) {
			content = content.replace(word, "<span style='background-color:gold;color:tomato;'>" + word + "</span>");
			dto.setContent(content);
		}
		
		//현재 글에 달려있는 댓글 목록 가져오기
		ArrayList<ShadowCommentDTO> clist = dao.listComment(shadowseq);		
		req.setAttribute("clist", clist);		

		req.setAttribute("isSearch", isSearch);
		
		req.setAttribute("column", column);
		req.setAttribute("word", word);
		
		req.setAttribute("dto", dto);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/shadow/view.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
