package com.wmc.board.shadow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 익명 게시판 게시물의 댓글 삭제하는 클래스
 * @author bey15
 *
 */
@WebServlet("/board/shadow/delcomment.do")
public class DelComment extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		//DelComment . java
		//1. 데이터 가져오기
		//2. DB작업  > DOA 위임(DELETE)
		//3. 결과 반환 + jsp 호출
		
		
		//삭제할 댓글 번호
		String shcseq = req.getParameter("shcseq"); 
		
		//돌아갈 부모글 번호
		String shadowseq = req.getParameter("shadowseq");
		
		ShadowDAO dao = new ShadowDAO();
		
		int result = dao.delComment(shcseq);
		
		req.setAttribute("result", result);
		req.setAttribute("shadowseq", shadowseq);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/shadow/delcomment.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
