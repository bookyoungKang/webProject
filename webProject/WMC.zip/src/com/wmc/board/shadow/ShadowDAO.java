package com.wmc.board.shadow;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

/**
 * 익명 게시판 정보 DB 연동을 위한 클래스
 * @author bey15
 *
 */
public class ShadowDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	//--------------------------------------------------------------------
	/**
	 * DB연동을 위한 기초작업(생성자)
	 */
	public ShadowDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}
	//--------------------------------------------------------------------
	/**
	 * DB연동 자원 해제
	 */
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 익명 게시판 추가하는 메소드
	 * @param dto 추가할 게시물의 제목,내용 등의 정보
	 * @return 성공 1 실패 0
	 */
	public int add(ShadowDTO dto) {
		try {
			
			String sql="INSERT INTO tblShadowBoard (shadowSeq, id, subject, content, regdate, cnt) values (shadowboard_seq.nextval, ? , ? , ? , default, default)";
			
			stat = conn.prepareStatement(sql);
			
						
			stat.setString(1, dto.getId());
			stat.setString(2, dto.getSubject());
			stat.setString(3, dto.getContent());
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.add : " + e.toString());
			
		}
		
		
		
		return 0;
	}
	
	/**
	 * 익명 게시판 게시물들 가져오는 메소드
	 * @param map 검색종류, 검색어, 가져올 정보개수
	 * @return 익명 게시판 게시물
	 */
	public ArrayList<ShadowDTO> list(HashMap<String, String> map) {
		try {
			
			//검색 쿼리
			String where = "";
			
			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'"
														, map.get("column")					                                                                                                                                                                         
														, map.get("word"));
			}
			
			
			//공지사항 맨위로 쿼리
			String sql = String.format("select 0, a.* from vwshadowb a where notice = 1 union select * from" + 
					"(select rownum as rnum, a.* from" + 
					"(select * from vwshadowb where notice = 0 %s order by shadowseq desc) a)" + 
					"where rnum between %s and %s" 		, where
														, map.get("begin")
														, map.get("end")
														);
			
				stat = conn.prepareStatement(sql);
			
				rs = stat.executeQuery();
			
			ArrayList<ShadowDTO> list = new ArrayList<ShadowDTO>();
			
												
			//불러오기
			while (rs.next()) {
				
				ShadowDTO dto = new ShadowDTO();
				
				dto.setShadowseq(rs.getString("shadowseq")); //글번호
				dto.setSubject(rs.getString("subject")); //제목
				dto.setId(rs.getString("id")); //id
				dto.setContent(rs.getString("content")); //내용
				dto.setRegdate(rs.getString("regdate")); //작성시간
				dto.setCnt(rs.getInt("cnt")); //조회수	
				dto.setNotice(rs.getString("notice"));
				
				dto.setGap(rs.getInt("gap")); //최신글
				dto.setName(rs.getString("name")); //이름
				dto.setCommentcount(rs.getInt("commentcount")); //댓글수
				
				
				list.add(dto);
			}
			
			return list;	
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.list : " + e.toString());
			
		}
		
		return null;
	}
	
	/**
	 * 조건에 맞는 익명 게시판 게시물 총 개수
	 * @param map 검색종류, 검색어
	 * @return 조건에 맞는 게시판 게시물 총개수
	 */
	public int getTotalCount(HashMap<String, String> map) {
		try {
			
			//검색 쿼리
			String where = "";
			
			if(map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'" , map.get("column")
															   , map.get("word"));
			
			}//if
			
			//전체 카운트 쿼리
			String sql = String.format("select count(*) as allcnt from vwshadowb %s", where);
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			
			if(rs.next()) {
				return rs.getInt("allcnt");
			}
			
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.getTotalCount : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 익명 게시판 게시물 글 삭제
	 * @param shadowseq 게시물 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int del(String shadowseq) {
		
		try {
			
			String sql1 = "DELETE FROM tblShadowComment where pshadowSeq = ?";
			String sql2 = "DELETE FROM tblShadowBoard where shadowseq = ?";
			
			stat = conn.prepareStatement(sql1);
			stat.setString(1, shadowseq);
			
			stat.executeUpdate();
			
			stat = conn.prepareStatement(sql2);
			stat.setString(1, shadowseq);		
			
			
			
			return stat.executeUpdate();
			
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.del : " + e.toString());
			
		}
		
		
		
		return 0;
	}
	
	/**
	 * 수정할 게시글 정보 가져오는 메소드
	 * @param shadowseq 수정할 게시글 시퀀스 번호
	 * @return 수정할 게시글
	 */
	public ShadowDTO get(String shadowseq) {
		try {
			
			String sql="select b.*, (select name from tblMember where id = b.id)" + 
					"as name from tblShadowboard b where shadowseq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, shadowseq);
			
			rs = stat.executeQuery();
			
			ShadowDTO dto = new ShadowDTO();
			
			if (rs.next()) {
				
				dto.setShadowseq(rs.getString("shadowseq")); //글번호
				dto.setSubject(rs.getString("subject")); //제목
				dto.setId(rs.getString("id")); //id
				dto.setContent(rs.getString("content")); //내용
				dto.setRegdate(rs.getString("regdate")); //작성시간
				dto.setCnt(rs.getInt("cnt")); //조회수
				dto.setName(rs.getString("name"));
				
				//dto.setGap(rs.getInt("gap"));				
				return dto;
				
			}
			
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.get : " + e.toString());
			
		}
		
		return null;
	}
	
	/**
	 * 익명 게시판 게시글 수정하는 메소드
	 * @param dto 기존 게시글 정보
	 * @return 성공 1 실패 0
	 */
	public int edit(ShadowDTO dto) {
		try {
			
			String sql="UPDATE tblShadowBoard set subject = ?, content = ? where shadowseq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getSubject());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getShadowseq());
			
			return stat.executeUpdate();
						
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.edit : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 익명 게시판 조회수 증가하는 메소드
	 * @param shadowseq 게시판 시퀀스 번호
	 */
	public void addCnt(String shadowseq) {
		try {
			
			String sql="UPDATE tblShadowBoard set cnt = cnt + 1 where shadowseq = ?";
			stat = conn.prepareStatement(sql);
		
			stat.setString(1, shadowseq);
			
			stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.addCnt : " + e.toString());
			
		}
		
		
	}
	
	/**
	 * 익명게시판 댓글 목록가져오는 메소드
	 * @param shadowseq 게시글 시퀀스 번호
	 * @return 댓글 리스트
	 */
	public ArrayList<ShadowCommentDTO> listComment(String shadowseq) {
		try {
			
			String sql="select c.*, (select name from tblMember where id = c.id) as name from tblShadowComment c where pshadowseq = ? order by shcseq desc";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, shadowseq);
			
			ArrayList<ShadowCommentDTO> clist = new ArrayList<ShadowCommentDTO>();
			rs = stat.executeQuery();
			
			while (rs.next()) {
				
				ShadowCommentDTO cdto = new ShadowCommentDTO();
				
				cdto.setShcseq(rs.getString("shcseq"));
				cdto.setContent(rs.getString("content"));
				cdto.setName(rs.getString("name"));
				cdto.setId(rs.getString("id"));
				cdto.setPshadowseq(rs.getString("pshadowseq"));
				
				clist.add(cdto);
				
			}
			
			return clist;
			
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.listComment : " + e.toString());
			
		}
		
		return null;
	}
	/**
	 * 익명게시판 댓글 추가하는 메소드
	 * @param cdto 댓글내용, 작성자, 게시글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int addComment(ShadowCommentDTO cdto) {
		try {
			
			String sql="INSERT INTO tblShadowComment (shcSeq, content, regdate, pshadowSeq, id) values (shadowcomment_seq.nextval, ? , default, ?, ?)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getPshadowseq());
			stat.setString(3, cdto.getId());
			
			
			return stat.executeUpdate();
			
			
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.addComment : " + e.toString());
			
		}
		
		
		return 0;
	}
	/**
	 * 익명 게시판 댓글 삭제하는 메소드
	 * @param shcseq 게시글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delComment(String shcseq) {
		try {
			
			String sql="DELETE FROM tblShadowComment WHERE shcseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, shcseq);
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.delComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 익명 게시판 댓글 수정하기
	 * @param cdto 기존 댓글 내용, 게시글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int editComment(ShadowCommentDTO cdto) {
		
		try {
			
			String sql="UPDATE tblShadowComment set content = ? where shcseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getShcseq());
			
			return stat.executeUpdate();
						
			
		} catch (Exception e) {
			
			System.out.println("ShadowDAO.editComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	
	
	
}//class
