package com.wmc.board.bookup;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

/**
 * 교재 추천 겟판 정보 DB연동 클래스
 * @author bey15
 *
 */
public class BookDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	/**
	 * DB연동을 위한 기초 작업 메소드 (생성자)
	 */
	public BookDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}
	/**
	 * DB 연동 자원을 닫는 메소드
	 */
	public void close() {
		try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
	}	
	
	/**
	 * 새글인지 확인하는 메소드
	 * @return
	 */
	public int getMaxThread() {
		try {
			
			String sql = "select nvl(max(thread), 0) + 1000 as thread from tblbookup";
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("thread");
			}
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.getMaxThread : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 교재 추천 게시판 시퀀스번호 얻어오는 메소드
	 * @return
	 */
	public String getSeq() {
		try {
			
			String sql="SELECT MAX(bookseq) AS bookseq FROM tblBookup";
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getString("bookseq");
			}
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.getSeq : " + e.toString());
			
		}
		
		
		
		return null;
	}
	
	/**
	 * 답글 메소드
	 * @param parentThread
	 * @param previousThread
	 */
	public void updateThread(int parentThread, int previousThread) {
		try {
			
			String sql="UPDATE tblbookup set thread = thread - 1 where thread > ? and thread < ?";
			
			stat = conn.prepareStatement(sql);
			stat.setInt(1, previousThread);
			stat.setInt(2, parentThread);
			
			stat.executeUpdate();
			
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.updateThread : " + e.toString());
			
		}
		
		
	}
	
	/**
	 * 교재 추천 게시판 게시물 추가 메소드
	 * @param dto 게시물 제목, 내용, 작성자 등 추가할 게시판 정보
	 * @return 성공 1 실패 0
	 */
	public int add(BookDTO dto) {
		try {
			
			String sql="INSERT into tblbookup" + 
					"(bookseq, id, subject, content, writer, price, love, regdate, cnt, notice, filename, orgfilename, downloadcount)" + 
					"values" + 
					"(bookup_seq.nextval, ?, ?, ?, ?, ?, ?, default, default, ?, ?, ?, default)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getId());
			stat.setString(2, dto.getSubject());
			stat.setString(3, dto.getContent());
			stat.setString(4, dto.getWriter());
			stat.setString(5, dto.getPrice());	
			stat.setInt(6, dto.getLove());
			stat.setString(7, dto.getNotice());
			stat.setString(8, dto.getFilename());
			stat.setString(9, dto.getOrgfilename());		
			
			return stat.executeUpdate();
			
			
			
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.add : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 교재 추천 게시판 게시물 전체 게시물 수 가져오는 메소드
	 * @param map 검색종류, 검색내용
	 * @return 게시물 총 개수
	 */
	public int getTotalCount(HashMap<String, String> map) {
		try {
			
			String where = "";
			
			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'"
														, map.get("column")
														, map.get("word"));
			}
						
			
			
			String sql = String.format("select count(*) as allcnt from vwbookupb %s"
																	, where);
															
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				
				return rs.getInt("allcnt");
			}	
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.getTotalCount : " + e.toString());
			
		}
		
		return 0;
	}
	
	
	/**
	 * 교재 추천 게시판 목록 가져오는 메소드
	 * @param map 검색종류, 검색내용, 게시물 가져올 수
	 * @return 교재추천게시판 게시물 목록
	 */
	public ArrayList<BookDTO> list(HashMap<String, String> map) {
		try {
			
			String where = "";
			//검색 쿼리
			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'"
														, map.get("column")
														, map.get("word"));
			}
						
			
						
			//리스트 쿼리
			String sql = String.format("select 0, a.* from vwbookupb a where notice = 1 union select * from " + 
					"    (select rownum as rnum, a.* from " + 
					"        (select * from vwbookupb where notice = 0 %s order by love desc) a) " + 
					"            where rnum between %s and %s"
																, where
																, map.get("begin")
																, map.get("end"));			
			
			stat = conn.prepareStatement(sql);
			
			rs = stat.executeQuery();
			
			ArrayList<BookDTO> list = new ArrayList<BookDTO>();
			
			
			
			while (rs.next()) {
				//레코드 1개 > DTO 1개
				BookDTO dto = new BookDTO();
				
				dto.setBookseq(rs.getString("bookseq"));
				dto.setId(rs.getString("id"));
				dto.setSubject(rs.getString("subject"));
				
				dto.setName(rs.getString("name"));
				dto.setContent(rs.getString("content"));	 
				
				dto.setRegdate(rs.getString("regdate"));
				dto.setCnt(rs.getInt("cnt"));//조회수				
				dto.setGap(rs.getInt("gap"));//최신글
				dto.setLove(rs.getInt("love"));
				
				dto.setCommentcount(rs.getInt("commentcount"));//댓글수				
				dto.setNotice(rs.getString("notice"));//공지글				
									
							
				
				list.add(dto);				
			}
			
			return list;
			
			
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.list : " + e.toString());
			
		}
		
		return null;
	}
	
	/**
	 * 교재추천 게시판 조회수 증가 메소드
	 * @param bookseq 교재추천 게시판 시퀀스 번호
	 */
	public void addCnt(String bookseq) {
		try {
			
			String sql="UPDATE tblbookup set cnt = cnt + 1 where bookseq = ?";
			stat = conn.prepareStatement(sql);
		
			stat.setString(1, bookseq);
			
			stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.addCnt : " + e.toString());
			
		}
		
		
	}
	
	/**
	 * 교재추천 게시판 리스트 가져오는 메소드
	 * @param bookseq 교재추천 게시판 시퀀스 번호
	 * @return
	 */
	public BookDTO get(String bookseq) {
		
	
		try {
			
			String sql = "select b.*, (select name from tblMember where id = b.id) as name from tblbookup b where bookseq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, bookseq);
			
			rs = stat.executeQuery();
			
			BookDTO dto = new BookDTO();
			
			if (rs.next()) {
				
				dto.setBookseq(rs.getString("bookseq"));
				dto.setId(rs.getString("id"));
				dto.setSubject(rs.getString("subject"));
				dto.setWriter(rs.getString("writer"));
				dto.setPrice(rs.getString("price"));
				dto.setContent(rs.getString("content"));
				dto.setLove(rs.getInt("love"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setCnt(rs.getInt("cnt"));			
				dto.setName(rs.getString("name"));//*				
				dto.setFilename(rs.getString("filename"));
				dto.setOrgfilename(rs.getString("orgfilename"));
				dto.setDownloadcount(rs.getString("downloadcount"));
							
				
				return dto;	
			}
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.get : " + e.toString());
			
		}
		
		return null;
	}
		
		
	/**
	 * 교재추천게시판 댓글 목록 메소드
	 * @param bookseq 교재추천게시판 시퀀스 번호
	 * @return 해당 게시판의 댓글목록
	 */
	public ArrayList<BookCommentDTO> listComment(String bookseq) {
		try {
			
			String sql = "select c.*, (select name from tblMember where id = c.id) as name from tblBookComment c where pbookSeq = ? order by bcseq desc";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, bookseq);
			
			ArrayList<BookCommentDTO> clist = new ArrayList<BookCommentDTO>();
			rs = stat.executeQuery();
			
			while (rs.next()) {
				
				BookCommentDTO cdto = new BookCommentDTO();
				
				cdto.setBcseq(rs.getString("bcseq"));
				cdto.setContent(rs.getString("content"));
				cdto.setName(rs.getString("name"));
				cdto.setId(rs.getString("id"));
				cdto.setRegdate(rs.getString("regdate"));
				cdto.setPbookSeq(rs.getString("pbookSeq"));
				
				clist.add(cdto);
			}
			
			return clist;
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.listComment : " + e.toString());
			
		}
		
		return null;
	}
	
	/**
	 * 다운로드 횟수 얻어오는 메소드
	 * @param bookseq 교재추천게시판 시퀀스 번호
	 */
	public void updateDownloadCount(String bookseq) {
		try {
			String sql = "update tblbookup set downloadcount = downloadcount + 1 where bookseq = ?";

			stat = conn.prepareStatement(sql);
			stat.setString(1, bookseq);
			
			stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.updateDownloadCount : " + e.toString());
			
		}
		
		
	}
	
	/**
	 * 교재추천 게시판 게시물 수정 메소드
	 * @param dto 수정할 게시물 제목, 내용 등의 정보
	 * @return 성공 1 실패 0
	 */
	public int edit(BookDTO dto) {
		try {
			
			String sql = "update tblbookup set subject = ?, content = ?, writer = ?, price= ?, filename = ?, orgfilename = ? where bookseq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getSubject());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getWriter());
			stat.setString(4, dto.getPrice());			
			stat.setString(5, dto.getFilename());
			stat.setString(6, dto.getOrgfilename());
			stat.setString(7, dto.getBookseq());
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.edit : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 교재추천 게시판 댓글 추가 메소드
	 * @param cdto 추가할 댓글 내용, 게시판 시퀀스 번호, 작성자 정보
	 * @return 성공 1 실패 0
	 */
	public int addComment(BookCommentDTO cdto) {
		try {
			
			String sql="INSERT INTO tblbookComment (bcseq, content, regdate, pbookSeq, id) values (bookcomment_seq.nextval, ? , default, ?, ?)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getPbookSeq());
			stat.setString(3, cdto.getId());
			
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.addComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	
	/**
	 * 교재추천 게시판 댓글 삭제
	 * @param bcseq 교재추천 게시판 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int delComment(String bcseq) {
		try {
			
			String sql="DELETE FROM tblbookComment WHERE bcseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, bcseq);
			
			return stat.executeUpdate();		
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.delComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 교재추천 게시판 댓글 수정
	 * @param cdto 수정할 댓글내용, 댓글 시퀀스 번호
	 * @return 성공 1 실패 0
	 */
	public int editComment(BookCommentDTO cdto) {
		try {
			
			String sql="UPDATE tblbookComment set content = ? where bcSeq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getBcseq());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.editComment : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 교재추천 게시판 게시물 삭제 메소드
	 * @param bookseq 교재추천 게시판 게시물 번호
	 * @return 성공 1 실패 0
	 */
	public int del(String bookseq) {
		try {
			
			String sql1 = "DELETE FROM tblbookComment where pbookSeq = ?";
			String sql2 = "DELETE FROM tblbookup where bookseq = ?";
			
			stat = conn.prepareStatement(sql1);
			stat.setString(1, bookseq);
			
			stat.executeUpdate();
			
			stat = conn.prepareStatement(sql2);
			stat.setString(1, bookseq);		
			
			
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.del : " + e.toString());
			
		}
		
		return 0;
	}
	
	/**
	 * 좋아요 증가 메소드
	 * @param bookseq 교재추천 게시판 게시물 시퀀스 번호
	 */
	public void addlove(String bookseq) {
		try {
			
			String sql="UPDATE tblbookup set love = love + 1 WHERE bookseq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, bookseq);
			
			stat.executeUpdate();
			
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.addlove : " + e.toString());
			
		}
		
		
	}
	
	/**
	 * 좋아요 개수 얻어오기 메소드
	 * @param bookseq 교재추천 게시판 게시물 시퀀스 번호
	 * @return 좋아요 개수
	 */
	public int getlove(String bookseq) {
		try {
			
			String sql="SELECT love FROM tblbookup WHERE bookseq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, bookseq);
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("love");
			}
			
			
		} catch (Exception e) {
			
			System.out.println("BookDAO.getlove : " + e.toString());
			
		}
		
		return 0;
	}
	
	
	
	
	
}//class
	