package com.wmc.board.bookup;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 교재 추천 게시판 좋아요 클릭 횟수 클래스
 * @author bey15
 *
 */
@WebServlet("/board/bookup/lovecnt123.do")
public class Lovecnt123 extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String bookseq = req.getParameter("bookseq");

		BookDAO dao = new BookDAO();

		dao.addlove(bookseq);

		int lovelove = dao.getlove(bookseq);

		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");

		PrintWriter love123 = resp.getWriter();

		love123.println("{");
		love123.println("\"love\"" + ":\"" + lovelove + "\"");
		love123.println("}");

	}// doget

}// class
