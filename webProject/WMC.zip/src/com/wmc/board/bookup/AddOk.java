package com.wmc.board.bookup;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

/**
 * 교재추천 게시판 추가 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/board/bookup/addok.do")
public class AddOk extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddOk.java
				//1. 데이터 가져오기
				//2. DB 작업 > DAO 위임(insert)
				//3. 결과 반환 + JSP 호출
				
				//1.
				req.setCharacterEncoding("UTF-8");
				HttpSession session = req.getSession();
				
				//String id = session.getAttribute("id").toString();
				
				String id = session.getAttribute("certification").toString();
				
				
					
				
				//파일 첨부 준비
				String subject = "";
				String content = "";				
				String notice = "";
				String writer = "";
				
				String filename = "";				
				String orgfilename = "";								
				String price = "";	
				
				//int love = 0;
				
				
				//파일 첨부 - 파일첨부시에 멀티.겟파라메타로한다 아니면 널값임
				
				try {
					
					
					//WebContent > files
					MultipartRequest multi = new MultipartRequest(
																		req,
																		req.getRealPath("/files"),
																		1024 * 1024 * 100,
																		"UTF-8",
																		new DefaultFileRenamePolicy()
																	); //이 순간 > 첨부 파일 저장 완료
					
					price = multi.getParameter("price");
					writer = multi.getParameter("writer");									
					subject = multi.getParameter("subject");
					content = multi.getParameter("content");
					notice = multi.getParameter("notice");
					
					if (notice == null) notice = "0";
														
					filename = multi.getFilesystemName("attach");
					orgfilename = multi.getOriginalFileName("attach");
					//love = Integer.parseInt(multi.getParameter("love"));
					
										
				} catch (Exception e) {
					
					System.out.println("AddOk.doPost : " + e.toString());
				}
				
				
				//DB				
				BookDAO dao = new BookDAO();	
								
				BookDTO dto = new BookDTO();
				
				dto.setSubject(subject);
				dto.setContent(content);
				dto.setId(id);				
				dto.setNotice(notice);
			
				dto.setWriter(writer);
				dto.setPrice(price);			
				
				dto.setFilename(filename); //첨부 파일명
				dto.setOrgfilename(orgfilename);	
				//dto.setLove(love);
				
				
				
				int result = dao.add(dto);				
				
				
				req.setAttribute("result", result);	

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/bookup/addok.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
