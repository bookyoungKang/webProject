package com.wmc.board.bob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.wmc.DBUtil;

/**
 * 맛집 공유 DB 연동 클래스
 * @author bey15
 *
 */
public class BobDAO {
	

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	/**
	 * 맛집공유 DB 연동을 위한 초기화 메소드(생성자)
	 */
	public BobDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}

	/**
	 * 맛집 공유 목록을 가져올 메소드
	 * @return
	 */
	public ArrayList<BobDTO> listbob() {
		try {
			
			String sql="SELECT * FROM tblBob";
			
			stat = conn.prepareStatement(sql);
			
			rs = stat.executeQuery();
			
			
			ArrayList<BobDTO> list = new ArrayList<BobDTO>();
			
			while(rs.next()) {
				
				BobDTO dto = new BobDTO();
				dto.setBobseq(rs.getString("bobseq"));
				dto.setName(rs.getString("name"));
				dto.setContent(rs.getString("content"));
				dto.setLat(rs.getString("lat"));
				dto.setLng(rs.getString("lng"));				
				dto.setStar(rs.getString("star"));
				
				
				
				list.add(dto);
				
				
			}
			return list;
			
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.listbob : " + e.toString());
			
		}
		
		return null;
	}

	/**
	 * 맛집공유 목록 수정하는 메소드
	 * @param dto
	 * @return
	 */
	public int editCoffee(BobDTO dto) {
		try {
			
			String sql="update tblbob set name = ?, content = ? , star = ? where bobseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getStar());
			stat.setString(4, dto.getBobseq());

			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.editCoffee : " + e.toString());
			
		}
		
		return 0;
	}

	/**
	 * 맛집공유 리스트 추가하는 메소드
	 * @param dto 맛집이름, 내용, 좌표, 평점
	 * @return 성공 1 실패 0
	 */
	public int addBob(BobDTO dto) {
		try {
			
			String sql = "insert into tblbob (bobseq, name, content, lat, lng, star) values (bob_seq.nextval, ?, ?, ?, ?, ?)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getLat());
			stat.setString(4, dto.getLng());			
			stat.setString(5, dto.getStar());
			
			return stat.executeUpdate();
					
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.addBob : " + e.toString());
			
		}
		
				
		
		
		
		return 0;
	}

	/**
	 * 맛집공유 삭제하는 메소드
	 * @param dto 맛집정보 시퀀스 번호
	 * @return 성공 1 실패 0ㄴ
	 */
	public int delCoffee(BobDTO dto) {
		try {
			
			String sql="delete from tblbob where bobseq =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getBobseq());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.delCoffee : " + e.toString());
			
		}
		
		
		
		return 0;
	}

}
