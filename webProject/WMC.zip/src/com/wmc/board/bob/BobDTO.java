package com.wmc.board.bob;

/**
 * 위치좌표 데이터 클래스
 * @author bey15
 *
 */
public class BobDTO {

	private String bobseq;
	private String name;
	private String lat;
	private String lng;
	private String content;
	private String bob;
	private String coffee;

	public String getBob() {
		return bob;
	}

	public void setBob(String bob) {
		this.bob = bob;
	}

	public String getCoffee() {
		return coffee;
	}

	public void setCoffee(String coffee) {
		this.coffee = coffee;
	}

	public String getStar() {
		return star;
	}

	public void setStar(String star) {
		this.star = star;
	}

	private String star;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getBobseq() {
		return bobseq;
	}

	public void setBobseq(String bobseq) {
		this.bobseq = bobseq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

}
