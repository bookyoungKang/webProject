package com.wmc.member;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

/**
 * 회원 자발적 탈퇴 클래스
 * @author bey15
 *
 */
@WebServlet("/member/del.do")
public class Del extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//회원 자발적 탈퇴
		HttpSession session = req.getSession();
		
		String id = (String) session.getAttribute("certification");
		
		MemberDTO dto = new MemberDTO();
		MemberDAO dao = new MemberDAO();
		StudyDAO recruitdao = new StudyDAO();
		
		recruitdao.delrecruitStudy(id); // 탈퇴하는 아이디로 모집공고 작성되어있을시 삭제
		recruitdao.delrecruitStudyGroup(id); // 스터디 그룹 탈퇴
		
		dto.setId(id);
		
		int result = dao.del(dto);
		
		session.removeAttribute("certification");
		session.removeAttribute("name");
		session.removeAttribute("birth");
		session.removeAttribute("byear");
		session.removeAttribute("bmonth");
		session.removeAttribute("bday");
		session.removeAttribute("email");
		session.removeAttribute("emailId");
		session.removeAttribute("emailAddress");
		session.removeAttribute("address");
		session.removeAttribute("rating");
		
		PrintWriter writer = resp.getWriter();
		
		if (result == 1) {
			writer.println("<script>");
			writer.println("location.href = '/wmc/member/main.do';");
			writer.println("</script>");
			
		} else if (result == 0) {
			writer.println("<script>");
			writer.println("history.back();");
			writer.println("</script>");
		}
		
		
		

		
	}

}