package com.wmc.member;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 아이디 조회 클래스
 * @author bey15
 *
 */
@WebServlet("/member/idsearch.do")
public class IdSearch extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String idSearchName = req.getParameter("name");
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		String email3 = req.getParameter("email3");

		MemberDTO dto = new MemberDTO();

		dto.setName(idSearchName);
		if (email2.equals("") || email2 == null) {
			dto.setEmail(email1 + "@" + email3);
		} else {
			dto.setEmail(email1 + "@" + email2);
		}

		//System.out.println(dto.getName());

		MemberDAO dao = new MemberDAO();

		String SearchId = dao.idSearch(dto);
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		//System.out.println(SearchId);

		// req.setAttribute("SearchId", SearchId);

		PrintWriter writer = resp.getWriter();
		if (SearchId.equals("")) {
			SearchId = "존재하지 않는 아이디";
		}
		writer.print("{");
		writer.printf("\"id\":\"%s\"", SearchId);
		writer.print("}");

		writer.close();

	}

}