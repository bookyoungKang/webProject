package com.wmc.member;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 회원 등급 변경 클래스
 * @author bey15
 *
 */
@WebServlet("/member/gradechange.do")
public class GradeChange extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String id = req.getParameter("id");
		String grade = req.getParameter("grade");
		
		MemberDTO dto = new MemberDTO();
		
		dto.setId(id);
		dto.setGrade(grade);
		
		//System.out.println(dto.getId());
		//System.out.println(dto.getGrade());
		
		MemberDAO dao = new MemberDAO();
		
		int result = dao.gradeChange(dto);
		
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		
		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

		
	}

}