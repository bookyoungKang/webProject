package com.wmc.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 회원 가입 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/member/addok.do")
public class AddOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		
		String name = req.getParameter("name");
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		String byear = req.getParameter("byear");
		String bmonth = req.getParameter("bmonth");
		String bday = req.getParameter("bday");
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		String email3 = req.getParameter("email3");
		String address1 = req.getParameter("address1");
		String address2 = req.getParameter("address2");
		String address3 = req.getParameter("address3");
		
		MemberDTO dto = new MemberDTO();
		dto.setName(name);
		dto.setId(id);
		dto.setPw(pw);
		dto.setBirth(byear+"-"+bmonth+"-"+bday);
		
		if(email2.equals("1") || email2 == "1") {
			dto.setEmail(email1+"@"+email3);
		} else {
			dto.setEmail(email1+"@"+email2);
		}
		
		dto.setAddress(address1+" "+address2+" "+address3);
		
		MemberDAO dao = new MemberDAO();
		
		int result = dao.add(dto);

		req.setAttribute("result", result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/addok.jsp");
		dispatcher.forward(req, resp);
	}

}
