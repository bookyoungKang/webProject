package com.wmc.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 회원 정보 수정 확인 클래스
 * @author bey15
 *
 */
@WebServlet("/member/editok.do")
public class EditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		
		HttpSession session = req.getSession();
		
		String id = (String) session.getAttribute("certification");
		String pw = req.getParameter("pw");
		String address1 = req.getParameter("address1");
		String address2 = req.getParameter("address2");
		String address3 = req.getParameter("address3");
		
		MemberDTO dto = new MemberDTO();
		
		dto.setId(id);
		
		dto.setPw(pw);
		
		dto.setAddress(address1+" "+address2+" "+address3);
		
		//System.out.println(dto.getId());
		//System.out.println(dto.getPw());
		//System.out.println(dto.getAddress());
		
		MemberDAO dao = new MemberDAO();
		
		int result = dao.edit(dto);

		req.setAttribute("result", result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/editok.jsp");
		dispatcher.forward(req, resp);
	}

}