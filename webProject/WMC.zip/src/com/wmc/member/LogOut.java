package com.wmc.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * 로그아웃 클래스
 * @author bey15
 *
 */
@WebServlet("/member/logout.do")
public class LogOut extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

				//1.
				HttpSession session = req.getSession();
				
				session.removeAttribute("certification");
				session.removeAttribute("name");
				session.removeAttribute("birth");
				session.removeAttribute("byear");
				session.removeAttribute("bmonth");
				session.removeAttribute("bday");
				session.removeAttribute("email");
				session.removeAttribute("emailId");
				session.removeAttribute("emailAddress");
				session.removeAttribute("address");
				session.removeAttribute("rating");

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/logout.jsp");
		dispatcher.forward(req, resp);
	}

}