/**
 * 
 */

var memno = 1;
var taskno = 1;
var moduleno = 1;
var modeLeader = 0;

$(function() {
	
	// 수정시 이미 추가된 회원을 고려해 memno를 count ++해줘야 함.
	memno += $("#addMember input[type=hidden]").size(); 
	
	// 수정시 이미 추가된 모듈 테이블을 고려해 moduleno count ++
	moduleno += $("#module .tblModule").size();
	
	// 수정시 이미 추가된 task 수를 고려해 taskno ++;
	
	taskno += $("tr[id^='task']").size();
	
	// datePicker
	$("#projectStartDate").datepicker({dateFormat : "yy-mm-dd"});
	$("#projectStartDate").datepicker("option", "dateFormat", "yy-mm-dd");
	
	$("#projectEndDate").datepicker({dateFormat : "yy-mm-dd"});
	$("#projectEndDate").datepicker("option", "dateFormat", "yy-mm-dd");
	
	// 완료 >< 미완료
	$(".form-check-input").change(function() {

		if ($(this).is(":checked")) {
			
			$(this).next().text("완료");
			$(this).parent().next().val("1");
			
		}
		else {
			
			$(this).next().text("미완료");
			$(this).parent().next().val("0");
		}
	});
	
	
	// 모듈 테이블 추가
	$("#btnAddModule").click(function() {
		
		$("#module").append('<div class="tblModule"><table class="table table-bordered long tblAddModule" id="tblAddModule'+ moduleno +'"> <tr> <th colspan="3">기능<span onclick="delModule(this);" class="close">x</span></th> </tr> <tr> <th colspan="2"><input id="moduleName'+ moduleno +'" name="moduleName'+ moduleno +'" type="text" class="form-control" placeholder="기능명을 입력하세요" /></th> <th> <div class="dropdown"> <select required name= "moduleTaker'+ moduleno +'" id="moduleTaker'+ moduleno +'" class="form-control priority moduleTaker"> </select> </div> </th> </tr> <tr> <td>중요도</td> <td>업무</td> <td>상태</td> </tr> <tr id="task'+ taskno +'" pseq="'+ moduleno +'"> <td> <select name="m'+ moduleno +'_taskPriority'+ taskno +'" id="m'+ moduleno +'_taskPriority'+ taskno +'" class="form-control priority"> <option value="매우높음">매우높음</option> <option value="높음">높음</option> <option selected value="보통">보통</option> <option value="낮음">낮음</option> <option value="매우낮음">매우낮음</option> </select> </td> <td><input name="m'+ moduleno +'_taskname'+ taskno +'" id="m'+ moduleno +'_taskname'+ taskno +'" type="text" class="form-control" placeholder="업무명을 입력하세요" /></td> <td> <div class="form-check">   <input class="form-check-input" type="checkbox">   <label class="form-check-label" for="taskStatus'+ taskno +'">미완료</label>   <span style="cursor: pointer;" id="taskcheck'+ taskno +'" class="delModule" onclick="delTask(this);">[삭제]</span> </div> <input type="hidden" id="m' + moduleno + '_taskStatus'+ taskno +'" name="m' + moduleno + '_taskStatus'+ taskno +'" value="0"/> </td> </tr> </table> <input type="button" class="btn btn-default btnAddTask pull-right" id="btnAddTask'+ moduleno +'" value="업무추가하기" onclick="addTask(this);" /> <div style="clear: both;"></div> <hr/></div>');

		// 새로 만들어지는 모듈 테이블 select에 담당자 추가하기
		
		var tempIndex = 0;
		
		$('span[id^="label"]').each(function() {
			var name = $(this).text();

			$("#moduleTaker" + moduleno).append("<option value='" + $("#addMember input[type=hidden]").eq(tempIndex).val() + "'>"+ name +"</option>");
			
			tempIndex++;
		})
	
		moduleno++;
		taskno++;
		console.log("모듈 테이블 추가 후: " + moduleno);
		$(".form-check-input").change(function() {
			console.log($(this).is(":checked"));
			if ($(this).is(":checked")) {
				
				$(this).next().text("완료");
				$(this).parent().next().val("1");
				
			}
			else {
				
				$(this).next().text("미완료");
				$(this).parent().next().val("0");
			}
		});
	});
	
	
	// id 검색
	$("#btnSearch").click(function() {
			$.ajax({
			type: "GET",
			url: "/wmc/project/adddata.do?search=1", 
			data: "keyword=" + $("#keyword").val(),
			dataType: "json",
			success: function(result) {
				
				var temp ="";

				$("#trmodal").remove();
				$("#succeed").remove();
				$("#keyword").val("");

				if (result.length == 0) {
					temp = '<tr id="trmodal"> <td colspan="2">아이디가 존재하지 않습니다</td></tr>';
				} else {
					
					$(result).each(function(index, item) {
						
						if (modeLeader == 0) {
							temp += '<tr id="trmodal"> <td onclick=\'useid(\"'+ item.id +'\",\"'+ item.name +'\"); message();\'>'+ item.id +'</td> <td onclick=\'useid(\"'+ item.id +'\",\"'+ item.name +'\"); message();\'>'+ item.name +'</td> </tr>';
							
						}
						else if (modeLeader == 1) {
							temp += '<tr id="trmodal"> <td onclick=\'appointLeader(\"'+ item.id +'\",\"'+ item.name +'\"); message();\'>'+ item.id +'</td> <td onclick=\'appointLeader(\"'+ item.id +'\",\"'+ item.name +'\"); message();\'>'+ item.name +'</td> </tr>';
						}
					}); 
				}
				
				$("#resultModal").append(temp);
				modeLeader = 0;
				
			},
			error: function(a,b,c) {
				console.log(a,b,c);
			}
		}); 
	});
});

function modeLeaderOn() {
	modeLeader = 1;
	if ($("#addLeader").children("span").size() != 0) $("#addLeader").children("span").remove();
}

function modeLeaderOff() {
	modeLeader = 0;
}

function appointLeader(id, name) {
	
	if($("#addLeader").children("span").size() ==0) {
		
		$("#addLeader").append('<span class="label label-primary member" id="leader">'+ name +'</span> <span onclick="delLeader();" class="delMember">X</span> <input type="hidden" id="leaderId" name="projectLeader" value="'+ id +'" />');
		
		// 멤버에 팀장이 없으면 팀장을 추가
		var isThere = 0;
		
		$("#addMember").find("input[type=hidden]").each(function (index, item) {
			
			if (id == $(this).val()) isThere = 1; // 팀장 있음
			
		});
		
		if(isThere == 0) {//팀장 추가}
			useid(id, name);
		}
	}
}

function delLeader() {
	if ($("#addLeader").children("span").size() != 0) {
		
		$("#addLeader").children("span").remove();
		$("#addLeader").children("input[type=hidden]").remove();
	
	}
}

//업무 추가
function addTask(tag) {

	var modnum = tag.id.substring(10);

	var target = "#tblAddModule" + modnum;

	$(target).append('<tr id="task'+ taskno +'" pseq="'+ modnum +'"> <td> <select name="m'+ modnum +'_taskPriority'+ taskno +'" id="m'+ modnum +'_taskPriority'+ taskno +'" class="form-control priority"> <option value="매우높음">매우높음</option> <option value="높음">높음</option> <option selected value="보통">보통</option> <option value="낮음">낮음</option> <option value="매우낮음">매우낮음</option> </select> </td> <td><input name="m'+ modnum +'_taskname'+ taskno +'" id="m'+ modnum +'_taskname'+ taskno +'" type="text" class="form-control" placeholder="업무명을 입력하세요" /></td> <td> <div class="form-check">   <input class="form-check-input" type="checkbox">   <label class="form-check-label" for="taskStatus'+ taskno +'">미완료</label>   <span style="cursor: pointer;" id="taskcheck'+ taskno +'" class="delModule" onclick="delTask(this);">[삭제]</span> </div> <input type="hidden" id="m' + modnum + '_taskStatus'+ taskno +'" name="m' + modnum + '_taskStatus'+ taskno +'" value="0"/> </td> </tr>');

	taskno++;
	
	$(".form-check-input").change(function() {
		console.log($(this).is(":checked"));
		if ($(this).is(":checked")) {
			
			$(this).next().text("완료");
			$(this).parent().next().val("1");
			
		}
		else {
			
			$(this).next().text("미완료");
			$(this).parent().next().val("0");
		}
	});
	
}

function delTask(span) {
	//alert(span.id.substring(9));
	var trnum = span.id.substring(9);
	var tr = "#task" + trnum;
	
	// tr을 지우기 전에 tr의 부모인 table을 찍어서 그 자식 tr의 length가 4인지 검사,
	var table = $(span).parents("table");
	console.log("count", $(table).find("tr").length);
	
	
	if ($(table).find("tr").length == 4 && $("#module").find(".tblModule").length !=1) {
		$(table).parent().remove();
	}
	
	if ($("#module").find(".tblModule").length !=1) $(tr).remove();
};




// 아이디 사용하기
function useid(id, name) {
	
	// 이미 이름이 있는지 없는지 검사 있으면 isThere = 1;
	var isThere = 0;
	$("#addMember input[type=hidden]").each(function(index, item) {
		if (id == $(this).val()) {isThere =1;}
	})
	
	// 아직 이름이 없을 때 추가
	if(isThere == 0) {
		$("#addMember").append('<span class="label label-primary member" id="label'+ memno +'">'+ name +'</span> <span onclick="delMember(this, '+ memno +');" class="delMember">X</span> <input type="hidden" id="member'+ memno +'" name="member'+ memno +'" value="'+ id +'" />');
		memno++; 
	}
	
	var isOption = 0;
	
	$(".moduleTaker option").each(function(index, item) {
		if (id == $(this).val()) {isOption = 1;}
	
	})
	
	if (isOption == 0) $(".moduleTaker").append('<option value="'+ id +'">'+ name +'</option>');
	leaderMode = 0;
}

// 모달 멤버 추가 성공 메시지
function message() {
	$("#modalmessage").append("<span id='succeed' style='color: cornflowerblue;' class='center'>추가완료</span>");
}

// 모달창 리셋
function resetresult() {
	$("#keyword").val("");
	$("#succeed").remove();
	$("#trmodal").remove();
}

// 멤버 삭제
function delMember(span, num) {
	
	console.log("member: "+$("#member" + num).val() + "vs leader: " + $("#leaderId").val() )
	
	
	// 삭제하는 멤버와 팀장이 같을 때 팀장 지우기
	if ($("#member" + num).val() == $("#leaderId").val()) {
		$("#leaderId").remove();
		$("#leader").next().remove();
		$("#leader").remove();
		
	} 
	
	$(".moduleTaker > option").each(function(index, item) {

		if ($(this).text() == $("#label" + num).text()) {
			$(this).remove();
		} 
	});
		
	$().next().attr("id")
	$("#label" + num).remove();
	$("#member" + num).remove();
	$(span).remove();
	
}

function delModule(span) {
	
	if ($("#module").find("table").length != 1)
	
		$(span).parents(".tblAddModule").siblings("input").remove();
		$(span).parents(".tblAddModule").siblings("div").remove();
		$(span).parents(".tblAddModule").siblings("hr").remove();
		$(span).parents(".tblAddModule").remove();
}







