/**
 * 
 */
var taskSeq = 0;
var proSeq = 0;
var seqToGo = 0;
$(function() {
	
	$("#delete").click(function() {
		$.ajax({
			type: "GET",
			url: "/wmc/project/deltaskdata.do?taskSeq=" + taskSeq,
			dataType: "json",
			success: function(result) {
				console.log(result.result)
				if (result.result ==1) {
					
					alert("삭제 성공");
					location.href="/wmc/project/view.do?seq=" + seqToGo;
					
				} else {
					alert("오류 발생");
				}
			},
			error: function(a,b,c) {
				console.log(a,b,c);
			} 
		})
	});
	
	
	$("#note").height($("#team").height());
});

function saveSeq(seq, seq2) {
	taskSeq = seq;
	proSeq = seq2;
}

function spec(span, num) {
	
	var modName = $("#span" + num).data("module");
	
	$("#tr" + num).after('<tr id="row'+num+'"><th class="modName">모듈명</th><td colspan="4">'+ modName+ '</td><td onclick="closeUp('+num+', \''+modName+'\');"><span class="glyphicon glyphicon-chevron-up"></span></td></tr>');
	
	span.remove();
}

function closeUp(num, modName) {
	
	var openDown = '<span id = "span'+ num+ '" class="glyphicon glyphicon-chevron-down" data-module = "'+ modName +'" onclick="spec(this, '+ num+ ');"></span>';
	
	$("#tr" + num).find("td:last-child").append(openDown);
	
	$("#row" + num).remove();
}

function edit(taskSeq){ 
	location.href="/wmc/project/editTask?seq=" + taskSeq;
}

function saveProSeq(seq) {
	seqToGo = seq;
}




