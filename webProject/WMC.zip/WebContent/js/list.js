/**
 * 
 */

var projectName;
var id1;
var projectSeq;
var input;
$(function() {

	$("#btnSearch").click(function() {
		
		if (projectName == $("#keyword").val()) {
			$.ajax({
				type:"GET",
				url: "/wmc/project/del.do",
				data: "seq=" + projectSeq + "&id=" + id1,
				dataType: "json",
				success: function(result) {
					if (result.result ==1) {
						
						alert("삭제 성공");
						location.href="/wmc/project/list.do";
						
					} else {
						alert("오류 발생");
					}
					
				},
				error: function(a,b,c) {
					console.log(a,b,c);
				}
			})
		}
	});
	
	
});

function saveName(name, id, seq) {
	projectName = name;
	id1 = id;
	projectSeq = seq;
}


